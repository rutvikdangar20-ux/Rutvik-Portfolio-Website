// Global Web Audio API Synthesizer for high-quality, lightweight sound effects without external asset dependencies.
// Persists mute state locally in localStorage.

class AudioSynthManager {
  private muted: boolean = false;
  private listeners: Set<(muted: boolean) => void> = new Set();

  constructor() {
    try {
      const savedMute = localStorage.getItem("rutvik_sound_muted");
      if (savedMute !== null) {
        this.muted = savedMute === "true";
      } else {
        // Default to active unmuted for rich experience
        this.muted = false;
      }
    } catch {
      this.muted = false;
    }
  }

  public isMuted(): boolean {
    return this.muted;
  }

  public setMuted(val: boolean) {
    this.muted = val;
    try {
      localStorage.setItem("rutvik_sound_muted", String(val));
    } catch (e) {
      // Ignored
    }
    this.notify();
  }

  public subscribe(callback: (muted: boolean) => void) {
    this.listeners.add(callback);
    return () => {
      this.listeners.delete(callback);
    };
  }

  private notify() {
    this.listeners.forEach((cb) => cb(this.muted));
  }

  private getContext(): AudioContext | null {
    if (this.muted) return null;
    try {
      const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioContextClass) return null;
      return new AudioContextClass();
    } catch {
      return null;
    }
  }

  /**
   * Quick high-quality subtle digital click/tap sound
   */
  public playClick() {
    const ctx = this.getContext();
    if (!ctx) return;

    try {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = "sine";
      osc.frequency.setValueAtTime(800, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(1500, ctx.currentTime + 0.05);

      gain.gain.setValueAtTime(0.015, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.06);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start(ctx.currentTime);
      osc.stop(ctx.currentTime + 0.06);
    } catch {
      // Audio context blocked
    }
  }

  /**
   * Super elegant "Water Droplet" / Plop sound (pani ki bund)
   */
  public playWaterDrop() {
    const ctx = this.getContext();
    if (!ctx) return;

    try {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      const filter = ctx.createBiquadFilter();

      // Clear water drop pitch sweep: rapid up-sweep creates the bubble/plop quality
      osc.type = "sine";
      // starts around 180Hz and sweeps rapidly to 900+ Hz
      osc.frequency.setValueAtTime(220, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(1100, ctx.currentTime + 0.14);

      // Lowpass/Bandpass filter to isolate sweet clean bubble tones
      filter.type = "bandpass";
      filter.frequency.setValueAtTime(600, ctx.currentTime);
      filter.frequency.exponentialRampToValueAtTime(1400, ctx.currentTime + 0.14);
      filter.Q.setValueAtTime(3, ctx.currentTime);

      // Tiny natural amplitude envelope
      gain.gain.setValueAtTime(0.001, ctx.currentTime);
      gain.gain.linearRampToValueAtTime(0.08, ctx.currentTime + 0.015);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.18);

      osc.connect(filter);
      filter.connect(gain);
      gain.connect(ctx.destination);

      osc.start(ctx.currentTime);
      osc.stop(ctx.currentTime + 0.2);

      // Delicate echo/secondary droplet micro-resonance
      setTimeout(() => {
        if (this.muted) return;
        try {
          const tinyCtx = this.getContext();
          if (!tinyCtx) return;
          const osc2 = tinyCtx.createOscillator();
          const gain2 = tinyCtx.createGain();
          
          osc2.type = "sine";
          osc2.frequency.setValueAtTime(800, tinyCtx.currentTime);
          osc2.frequency.exponentialRampToValueAtTime(1200, tinyCtx.currentTime + 0.04);
          
          gain2.gain.setValueAtTime(0.012, tinyCtx.currentTime);
          gain2.gain.exponentialRampToValueAtTime(0.0001, tinyCtx.currentTime + 0.05);
          
          osc2.connect(gain2);
          gain2.connect(tinyCtx.destination);
          
          osc2.start(tinyCtx.currentTime);
          osc2.stop(tinyCtx.currentTime + 0.05);
        } catch {}
      }, 70);

    } catch {
      // Audio context blocked
    }
  }

  /**
   * Sound for opening modal or drawer - upward modern swell
   */
  public playOpenSwell() {
    const ctx = this.getContext();
    if (!ctx) return;

    try {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = "sine";
      osc.frequency.setValueAtTime(300, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(650, ctx.currentTime + 0.25);

      gain.gain.setValueAtTime(0.001, ctx.currentTime);
      gain.gain.linearRampToValueAtTime(0.03, ctx.currentTime + 0.1);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.25);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start(ctx.currentTime);
      osc.stop(ctx.currentTime + 0.25);
    } catch {}
  }

  /**
   * Sound for closing modal or drawer - downward modern fade
   */
  public playCloseSwell() {
    const ctx = this.getContext();
    if (!ctx) return;

    try {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = "sine";
      osc.frequency.setValueAtTime(550, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(250, ctx.currentTime + 0.2);

      gain.gain.setValueAtTime(0.02, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.2);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start(ctx.currentTime);
      osc.stop(ctx.currentTime + 0.2);
    } catch {}
  }

  /**
   * Gentle micro chime on successful operations or ticks
   */
  public playChime() {
    const ctx = this.getContext();
    if (!ctx) return;

    try {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = "sine";
      osc.frequency.setValueAtTime(880, ctx.currentTime); // A5 note

      gain.gain.setValueAtTime(0.001, ctx.currentTime);
      gain.gain.linearRampToValueAtTime(0.04, ctx.currentTime + 0.05);
      gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.35);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start(ctx.currentTime);
      osc.stop(ctx.currentTime + 0.36);
    } catch {}
  }

  /**
   * Synthesize an epic arcade 3D sci-fi rocket flight/ignition sound.
   * Fine-tuned to start perfectly from 0 volume, swell gradually and softly,
   * avoiding any loud startling spikes for a smooth sensory experience.
   */
  public playRocketLaunch() {
    const ctx = this.getContext();
    if (!ctx) return;
    try {
      const now = ctx.currentTime;

      // 1. Cozy ultra-low frequency grounding air sweep (deep engine resonance)
      const rumbleOsc = ctx.createOscillator();
      const rumbleGain = ctx.createGain();
      rumbleOsc.type = "sine"; // sine is much smoother and gentler than triangle/sawtooth
      rumbleOsc.frequency.setValueAtTime(45, now);
      rumbleOsc.frequency.exponentialRampToValueAtTime(110, now + 2.2);
      
      // Starts clean at 0, ramps up slowly to a very safe, non-startling low volume
      rumbleGain.gain.setValueAtTime(0.0, now);
      rumbleGain.gain.linearRampToValueAtTime(0.015, now + 0.8); // Gentle 0.8s swell
      rumbleGain.gain.exponentialRampToValueAtTime(0.0001, now + 2.6);

      // 2. Futuristic aerodynamic wind/thrust sweep (soft smooth swoosh)
      const thrustOsc = ctx.createOscillator();
      const thrustGain = ctx.createGain();
      const filter = ctx.createBiquadFilter();

      thrustOsc.type = "triangle"; // triangle is softer than sawtooth
      thrustOsc.frequency.setValueAtTime(120, now);
      thrustOsc.frequency.exponentialRampToValueAtTime(320, now + 2.0);

      filter.type = "lowpass";
      filter.frequency.setValueAtTime(150, now);
      filter.frequency.exponentialRampToValueAtTime(600, now + 1.6);
      filter.Q.setValueAtTime(1.0, now);

      // Starts clean at 0, sweeps up sweet and slow
      thrustGain.gain.setValueAtTime(0.0, now);
      thrustGain.gain.linearRampToValueAtTime(0.012, now + 0.9); // Gentle 0.9s swell
      thrustGain.gain.exponentialRampToValueAtTime(0.0001, now + 2.4);

      rumbleOsc.connect(rumbleGain);
      rumbleGain.connect(ctx.destination);

      thrustOsc.connect(filter);
      filter.connect(thrustGain);
      thrustGain.connect(ctx.destination);

      rumbleOsc.start(now);
      rumbleOsc.stop(now + 2.7);

      thrustOsc.start(now);
      thrustOsc.stop(now + 2.5);
    } catch (e) {
      console.error("Rocket ignition synth failed:", e);
    }
  }
}

export const audioSynth = new AudioSynthManager();
