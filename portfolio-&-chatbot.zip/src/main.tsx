import { StrictMode, useState, useEffect } from "react";
import { createRoot } from "react-dom/client";
import App from "./App.tsx";
import MessagesAdmin from "./components/MessagesAdmin.tsx";
import "./index.css";
import { ToastProvider } from "./components/ToastContext";
import { AnimatePresence, motion } from "framer-motion";

function MainRouter() {
  const [currentPath, setCurrentPath] = useState(window.location.pathname);

  useEffect(() => {
    const handleLocationChange = () => {
      setCurrentPath(window.location.pathname);
    };

    window.addEventListener("popstate", handleLocationChange);
    // Custom navigation triggers
    window.addEventListener("pushstate-nav", handleLocationChange);

    return () => {
      window.removeEventListener("popstate", handleLocationChange);
      window.removeEventListener("pushstate-nav", handleLocationChange);
    };
  }, []);

  return (
    <AnimatePresence mode="wait">
      {currentPath === "/admin/messages" ? (
        <motion.div
          key="admin-view"
          initial={{ opacity: 0, scale: 0.98 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.98 }}
          transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
          className="min-h-screen w-full bg-navy"
        >
          <MessagesAdmin />
        </motion.div>
      ) : (
        <motion.div
          key="app-view"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.3 }}
          className="min-h-screen w-full"
        >
          <App />
        </motion.div>
      )}
    </AnimatePresence>
  );
}

createRoot(document.getElementById("root")!).render(
  <StrictMode>
    <ToastProvider>
      <MainRouter />
    </ToastProvider>
  </StrictMode>,
);
