import React, { useEffect, useState } from "react";
import { motion, AnimatePresence, useScroll } from "framer-motion";
import Lenis from "lenis";
import Header from "./components/Header";
import Hero from "./Hero";
import About from "./components/About";
import Projects from "./components/Projects";
import Academics from "./components/Academics";
import IndustryVisits from "./components/IndustryVisits";
import Seminars from "../Seminars";
import Courses from "./components/Courses";
import Skills from "./components/Skills";
import Tools from "./components/Tools";
import ShaderBackground from "./components/ShaderBackground";
import WebsiteBuilder from "./components/WebsiteBuilder";

import Insights from "./components/Insights";
import Contact from "./components/Contact";
import GlowingFinishingSlide from "./components/GlowingFinishingSlide";
import Footer from "./components/Footer";
import Chatbot from "./components/Chatbot";
import RocketLaunchEffect from "./components/RocketLaunchEffect";
import ExitIntentPopup from "./components/ExitIntentPopup";
import PlainAmbientSlide from "./components/PlainAmbientSlide";

import { useToast } from "./components/ToastContext";
import { db } from "./components/firebase";
import { collection, onSnapshot, query } from "firebase/firestore";
import { audioSynth } from "./utils/audio";

export default function App() {
  const [isLoading, setIsLoading] = useState(true);
  const { addToast } = useToast();

  // Real-time globally synced message listener with custom chimes for prompt alerts
  useEffect(() => {
    try {
      const q = query(collection(db, "messages"));
      const pageLoadTime = Date.now();
      let isInitialLoad = true;

      const unsubscribe = onSnapshot(q, (snapshot) => {
        if (isInitialLoad) {
          isInitialLoad = false;
          return; // Skip reading historical database messages on initial screen load
        }

        snapshot.docChanges().forEach((change) => {
          if (change.type === "added") {
            const data = change.doc.data();
            const createdTimeMillis = data.createdAt?.toMillis ? data.createdAt.toMillis() : Date.now();
            
            // Allow 15s window to capture fresh entries submitted during current session
            if (createdTimeMillis && (createdTimeMillis > pageLoadTime - 15000)) {
              audioSynth.playChime();
              
              const senderName = data.name || "Anonymous Visitor";
              const snippet = data.message ? (data.message.length > 55 ? data.message.substring(0, 55) + "..." : data.message) : "Sent an attachment";
              
              addToast(`🔔 Message from ${senderName}: "${snippet}"`, "info");
            }
          }
        });
      }, (err) => {
        console.error("Real-time portfolio monitor error:", err);
      });

      return () => unsubscribe();
    } catch (err) {
      console.warn("Failed to set up real-time messages listener:", err);
    }
  }, [addToast]);

  const [isScrolled, setIsScrolled] = useState(false);
  const [isAnimationPaused, setIsAnimationPaused] = useState(() => {
    return localStorage.getItem('reduceMotion') === 'true';
  });
  
  const { scrollYProgress } = useScroll();

  // Clear scroll states or enforce top-alignment on a fresh page reload/refresh
  useEffect(() => {
    let isReload = false;
    try {
      // Enhanced bulletproof detection of a page reload / user refresh event (both modern navigation entries and legacy fallback API)
      const isLegacyReload = window.performance && window.performance.navigation && window.performance.navigation.type === 1;
      const navEntries = window.performance && window.performance.getEntriesByType && window.performance.getEntriesByType('navigation');
      const isModernReload = navEntries && navEntries.length > 0 && (navEntries[0] as any).type === 'reload';
      
      if (isLegacyReload || isModernReload) {
        isReload = true;
      }
    } catch (e) {
      // Safe fallback
    }

    if (isReload) {
      sessionStorage.removeItem('portfolio_scroll_pos');
      // Set to manual during reload to override native browser scroll restoration fully
      if ('scrollRestoration' in window.history) {
        window.history.scrollRestoration = 'manual';
      }
      window.scrollTo(0, 0);
    } else {
      if ('scrollRestoration' in window.history) {
        window.history.scrollRestoration = 'auto';
      }
    }
  }, []);

  // Global listener to sync animation pause states
  useEffect(() => {
    const handleToggle = () => {
      setIsAnimationPaused((prev) => {
        const next = !prev;
        if (next) {
          document.documentElement.classList.add("pause-animations");
        } else {
          document.documentElement.classList.remove("pause-animations");
        }
        return next;
      });
    };

    if (isAnimationPaused) {
      document.documentElement.classList.add("pause-animations");
    } else {
      document.documentElement.classList.remove("pause-animations");
    }

    window.addEventListener('toggle-background-animation', handleToggle);
    return () => {
      window.removeEventListener('toggle-background-animation', handleToggle);
    };
  }, [isAnimationPaused]);

  useEffect(() => {
    let lenis: Lenis | null = null;
    let rafId: number;
    
    try {
      // Instantiate Lenis for buttery-smooth kinetic scrolling
      lenis = new Lenis({
        duration: 1.25,
        easing: (t) => (t === 1 ? 1 : 1 - Math.pow(2, -10 * t)), // Elegant buttery exponential ease-out
        orientation: "vertical",
        gestureOrientation: "vertical",
        smoothWheel: true,
        syncTouch: true,
        wheelMultiplier: 1.15,
        touchMultiplier: 1.45,
      });

      function raf(time: number) {
        if (lenis) {
          lenis.raf(time);
        }
        rafId = requestAnimationFrame(raf);
      }
      
      rafId = requestAnimationFrame(raf);

      // Track scroll positions for active session preservation
      lenis.on('scroll', (e: any) => {
        if (e && e.scroll !== undefined) {
          sessionStorage.setItem('portfolio_scroll_pos', Math.round(e.scroll).toString());
        }
      });
    } catch (err) {
      console.warn("Lenis initialization skipped:", err);
    }

    const handleScrollEvent = () => {
      sessionStorage.setItem('portfolio_scroll_pos', Math.round(window.scrollY).toString());
    };
    window.addEventListener("scroll", handleScrollEvent, { passive: true });

    // Synchronize Lenis with loading state
    if (lenis) {
      if (isLoading) {
        lenis.stop();
      } else {
        lenis.start();

        // Premium animation-synced scroll restoration when preloader screen finishes
        const savedPos = sessionStorage.getItem('portfolio_scroll_pos');
        if (savedPos) {
          const y = parseInt(savedPos, 10);
          if (!isNaN(y) && y > 0) {
            setTimeout(() => {
              if (lenis) {
                lenis.scrollTo(y, { immediate: true });
              }
            }, 30);
          }
        }
      }
    }

    // Expose Lenis to window for smooth navigation scrolls
    if (lenis) {
      (window as any).lenisInstance = lenis;
    }

    // Global listener to capture click events on relative anchors and route them through Lenis
    const handleAnchorClick = (e: MouseEvent) => {
      const target = e.target as HTMLElement;
      const anchor = target.closest("a");
      if (anchor) {
        const href = anchor.getAttribute("href");
        if (href && href.startsWith("#") && href.length > 1) {
          e.preventDefault();
          // Skip internal custom routing anchors or specific popups
          if (href === "#" || anchor.hasAttribute("data-bypass-smooth-scroll")) return;
          const targetId = href.substring(1);
          const targetElement = document.getElementById(targetId);
          if (targetElement && lenis) {
            lenis.scrollTo(targetElement, { duration: 1.4, offset: -60 });
          }
        }
      }
    };
    document.addEventListener("click", handleAnchorClick);

    return () => {
      if (lenis) {
        lenis.destroy();
      }
      cancelAnimationFrame(rafId);
      window.removeEventListener("scroll", handleScrollEvent);
      document.removeEventListener("click", handleAnchorClick);
    };
  }, [isLoading]);

  useEffect(() => {
    if (isLoading) {
      document.body.style.overflow = "hidden";
      document.body.style.backgroundColor = "#590fb7"; // Cohesive preloader backdrop gradient sync
      document.documentElement.style.backgroundColor = "#590fb7";
    } else {
      document.body.style.overflow = "";
      document.body.style.backgroundColor = "";
      document.documentElement.style.backgroundColor = "";
    }
    return () => {
      document.body.style.overflow = "";
      document.body.style.backgroundColor = "";
      document.documentElement.style.backgroundColor = "";
    };
  }, [isLoading]);

  useEffect(() => {
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 600);

    // Call global motion initializer attached to window safely
    try {
      if (typeof (window as any).__initPortfolioMotion === 'function') {
          (window as any).__initPortfolioMotion();
      }
    } catch (err) {
      console.warn("Portfolio automatic motion init skipped:", err);
    }

    const handleScroll = () => {
      setIsScrolled(window.scrollY > 15);
    };
    window.addEventListener("scroll", handleScroll, { passive: true });

    return () => {
      clearTimeout(timer);
      window.removeEventListener("scroll", handleScroll);
    };
  }, []);

  return (
    <>
        <AnimatePresence>
          {isLoading && (
            <motion.div
              key="preloader"
              initial={{ opacity: 1 }}
              exit={{ opacity: 0, scale: 1.05 }}
              transition={{ duration: 0.3, ease: "easeInOut" }}
              onClick={() => setIsLoading(false)}
              title="Click or tap anywhere to skip loading screen"
              className="fixed inset-0 w-full h-full min-h-screen min-w-full z-[9999] mesh-preloader flex flex-col items-center justify-center overflow-hidden cursor-pointer select-none"
            >
              <motion.div
                initial={{ scale: 0.5, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                transition={{
                  type: "spring",
                  stiffness: 100,
                  damping: 20,
                  mass: 1,
                }}
                className="relative"
              >
                <div className="absolute inset-0 border-4 border-white/40 rounded-full animate-ping"></div>
                <div className="w-20 h-20 bg-transparent backdrop-blur-md border border-white/50 rounded-full flex items-center justify-center text-white font-serif text-3xl font-bold shadow-2xl z-10 relative">
                  R
                </div>
              </motion.div>
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{
                  delay: 0.2,
                  type: "spring",
                  stiffness: 100,
                  damping: 20,
                }}
                className="mt-6 text-white font-medium tracking-widest text-sm uppercase"
              >
                Loading Experience
              </motion.div>
              <motion.div
                className="h-1 bg-white/80 w-0 absolute bottom-0 left-0"
                animate={{ width: "100%" }}
                transition={{ duration: 0.5, ease: "easeInOut" }}
              />
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 0.4 }}
                transition={{ delay: 1.2 }}
                className="absolute bottom-6 text-[10px] text-white/50 tracking-widest uppercase font-mono"
              >
                Click anywhere to skip
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Glowing Top Red/Pink Edge Bar (visible at scroll 0, hides on scroll) */}
        <div 
          className={`fixed top-0 left-0 right-0 h-[8px] bg-gradient-to-r from-[#ff1b6b] via-[#ff2f4b] via-[#ff4e50] via-[#fd1c3a] to-[#e10022] z-[10000] shadow-[0_5px_30px_rgba(255,27,107,0.95)] transition-all duration-700 ease-in-out origin-top ${
            isScrolled ? "opacity-0 -translate-y-full pointer-events-none scale-y-0" : "opacity-100 translate-y-0 scale-y-100"
          }`}
        />

        <motion.div
          className="fixed top-0 left-0 right-0 h-1.5 bg-electric origin-left z-[9000] shadow-[0_0_10px_rgba(35,154,59,0.8)]"
          style={{ scaleX: scrollYProgress }}
        />

        <Header />

        <div className="relative w-full overflow-x-hidden min-h-screen flex flex-col bg-navy">
          {/* Light/Cream Content Base Wrapper */}
          <div className="bg-cream relative w-full flex flex-col">
            <ShaderBackground showControls={!isLoading} />
            <Hero />
            <About />
            <Projects />
            <Academics />
            <IndustryVisits />
            <Seminars />
            <Courses />
            <Skills />
            <Tools />
            <Insights />
            <WebsiteBuilder />
            <Contact />
          </div>

          {/* Glowing Concluding Slide */}
          <GlowingFinishingSlide />

          <Footer />
          <PlainAmbientSlide />
          <Chatbot />
          <RocketLaunchEffect />
          <ExitIntentPopup />
        </div>
        
    </>
  );
}
