import React, { useState, useEffect } from 'react';
import { Menu, X, Play, Pause, Bot } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { audioSynth } from '../utils/audio';
import { db, useProfile } from './firebase';
import { doc, onSnapshot } from 'firebase/firestore';
import { useToast } from './ToastContext';
import ProfessionalPhotoModal from './ProfessionalPhotoModal';

const navLinks = [
  { name: 'About', href: '#about' },
  { name: 'Projects', href: '#projects' },
  { name: 'Skills', href: '#skills' },
  { name: 'Contact', href: '#contact' },
];

export default function Header() {
  const { profile } = useProfile();
  const [isOpen, setIsOpen] = useState(false);
  const [isMotionPaused, setIsMotionPaused] = useState(false);
  const [rocketCount, setRocketCount] = useState<number | null>(null);
  
  // Custom states for the executive professional photo modal with session view calculation
  const [isPhotoOpen, setIsPhotoOpen] = useState(false);
  const [sessionPhotoViews, setSessionPhotoViews] = useState(0);
  const { addToast } = useToast();

  const handleOpenPhoto = () => {
    const nextCount = sessionPhotoViews + 1;
    setSessionPhotoViews(nextCount);
    addToast("✨ Opening Rutvik's Professional Profile Photo...", "success");
    audioSynth.playOpenSwell();
    setIsPhotoOpen(true);
  };

  useEffect(() => {
    // 1. Initial listener for real-time Firestore sync of rocket count
    const docRef = doc(db, "stats", "rocket_counter");
    const unsub = onSnapshot(docRef, (docSnap) => {
      if (docSnap.exists()) {
        setRocketCount(docSnap.data().count || 0);
      } else {
        setRocketCount(0);
      }
    }, (error) => {
      console.error("Header rocket count subscription error:", error);
    });

    // 2. Also listen to direct local updates for instant visual response
    const handleLocalUpdate = (e: Event) => {
      const customEvent = e as CustomEvent;
      if (customEvent.detail && typeof customEvent.detail.count === "number") {
        setRocketCount(customEvent.detail.count);
      }
    };
    window.addEventListener("rocket-count-updated", handleLocalUpdate);

    // 3. Listen to global professional photo modal trigger event
    const handleOpenPhotoEvent = () => {
      handleOpenPhoto();
    };
    window.addEventListener("open-photo-modal", handleOpenPhotoEvent);

    return () => {
      unsub();
      window.removeEventListener("rocket-count-updated", handleLocalUpdate);
      window.removeEventListener("open-photo-modal", handleOpenPhotoEvent);
    };
  }, []);

  useEffect(() => {
    // Clear dark mode completely and enforce light mode
    document.documentElement.classList.remove('dark');
    localStorage.removeItem('theme');
  }, []);

  useEffect(() => {
    setIsMotionPaused(localStorage.getItem('reduceMotion') === 'true');
    const handleToggle = () => setIsMotionPaused(localStorage.getItem('reduceMotion') === 'true');
    window.addEventListener('toggle-background-animation', handleToggle);
    return () => window.removeEventListener('toggle-background-animation', handleToggle);
  }, []);

  const toggleMotion = () => {
    window.dispatchEvent(new CustomEvent('toggle-background-animation'));
  };

  const scrollTo = (id: string) => {
    const sectionId = id.replace('#', '');
    const lenis = (window as any).lenisInstance;
    
    if (lenis) {
      if (sectionId === 'hero') {
        lenis.scrollTo(0, { duration: 1.4 });
      } else {
        const element = document.getElementById(sectionId);
        if (element) {
          lenis.scrollTo(element, { duration: 1.4, offset: -60 });
        }
      }
    } else {
      if (sectionId === 'hero') {
        window.scrollTo({ top: 0, behavior: 'smooth' });
      } else {
        document.getElementById(sectionId)?.scrollIntoView({ behavior: 'smooth' });
      }
    }
    setIsOpen(false);
  };

  return (
    <>
      <header className="fixed top-0 left-0 right-0 z-50 glass-panel transition-butter border-b border-white/40">
        <div className="max-w-7xl mx-auto px-6 h-20 flex items-center justify-between">
          <a href="#" onClick={(e) => { e.preventDefault(); scrollTo('#hero'); }} className="text-2xl font-serif font-bold text-navy">
            Rutvik D.
          </a>

          {/* Desktop Nav */}
          <nav className="hidden md:flex items-center gap-8">
            {navLinks.map((link) => (
              <a
                key={link.name}
                href={link.href}
                onClick={(e) => { e.preventDefault(); scrollTo(link.href); }}
                className="text-sm font-bold text-charcoal hover:text-electric transition-colors"
                id={`nav-link-${link.name.toLowerCase()}`}
              >
                {link.name}
              </a>
            ))}
          </nav>

          {/* Right Area Action Items */}
          <div className="flex items-center gap-3">
            {/* Professional Profile Photo Miniature Button next to Floating AI */}
            <button
              onClick={() => handleOpenPhoto()}
              className="w-9 h-9 rounded-full bg-gradient-to-tr from-sky-400 via-purple-500 to-rose-400 p-[1.5px] hover:scale-110 active:scale-95 transition-all cursor-pointer shadow-md overflow-hidden flex items-center justify-center group shrink-0"
              title="View Rutvik's Professional Photo 📷"
              id="header-profile-photo-btn"
            >
              <div className="w-full h-full rounded-full bg-[#1e1b4b] overflow-hidden relative flex items-center justify-center text-white text-[10px] font-black">
                <img 
                  src={profile.photoUrl} 
                  alt="RD" 
                  className="w-full h-full object-cover object-[center_12%] scale-[2.2] translate-y-[15%] group-hover:brightness-110 group-hover:scale-[2.4] transition-all pointer-events-none"
                  referrerPolicy="no-referrer"
                />
              </div>
            </button>

            {/* Upper Navigation Bar Floating AI Button */}
            <button
              onClick={() => {
                audioSynth.playOpenSwell();
                window.dispatchEvent(new CustomEvent("toggle-chatbot"));
              }}
              className="px-4.5 py-2 bg-navy text-white hover:bg-electric text-xs font-bold rounded-full transition-all duration-300 relative cursor-pointer flex items-center gap-1.5 group hover:scale-[1.05] active:scale-95 shadow-lg shadow-navy/10 border border-white/10"
              aria-label="Toggle AI Assistant"
              id="header-ai-assistant-btn"
            >
              <Bot size={14} className="animate-pulse" />
              <span className="hidden sm:inline">Floating AI</span>
              <div className="absolute -top-1 -right-1 w-3.5 h-3.5 bg-green-400 rounded-full border-2 border-white animate-pulse" />
            </button>

            {/* Mobile Menu Toggle button */}
            <div className="md:hidden relative flex flex-col items-center">
              <button 
                className="p-1.5 -mr-1 text-navy hover:text-electric transition-colors cursor-pointer flex flex-col items-center justify-center relative"
                onClick={() => setIsOpen(!isOpen)}
                aria-label="Toggle menu"
                id="mobile-menu-btn"
              >
                {isOpen ? <X size={24} /> : <Menu size={24} />}
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Mobile Nav */}
      <AnimatePresence>
        {isOpen && (
          <>
            {/* Backdrop Overlay */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.25 }}
              onClick={() => setIsOpen(false)}
              className="fixed inset-0 z-40 bg-navy/20 backdrop-blur-md md:hidden"
              id="mobile-drawer-overlay"
            />

            {/* Slide-In Drawer */}
            <motion.div
              initial={{ x: "100%" }}
              animate={{ x: 0 }}
              exit={{ x: "100%" }}
              transition={{ type: "spring", damping: 28, stiffness: 220 }}
              className="fixed right-0 top-0 bottom-0 w-[300px] max-w-[85vw] h-full z-50 bg-cream border-l border-navy/10 shadow-[0_0_50px_rgba(9,24,76,0.15)] p-6 flex flex-col md:hidden justify-between"
              id="mobile-drawer-container"
            >
              <div>
                <div className="flex items-center justify-between h-20 border-b border-navy/5 mb-8">
                  <span className="text-xl font-serif font-bold text-navy">Navigation</span>
                  <button 
                    onClick={() => setIsOpen(false)}
                    className="p-2 -mr-2 text-navy hover:text-electric transition-colors cursor-pointer"
                    aria-label="Close menu"
                    id="mobile-drawer-close-btn"
                  >
                    <X size={24} />
                  </button>
                </div>
                <nav className="flex flex-col gap-4">
                  {navLinks.map((link, idx) => (
                    <motion.a
                      key={link.name}
                      href={link.href}
                      onClick={(e) => { e.preventDefault(); scrollTo(link.href); }}
                      initial={{ opacity: 0, x: 30 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: idx * 0.05 }}
                      className="text-lg font-serif font-bold text-navy hover:text-electric transition-colors flex items-center justify-between py-3 px-4 rounded-xl hover:bg-navy/5 group"
                    >
                      <span>{link.name}</span>
                      <span className="text-navy/30 group-hover:text-electric font-sans font-normal text-sm transition-transform group-hover:translate-x-1">→</span>
                    </motion.a>
                  ))}

                  {/* Custom Photo navigation link immediately under Contact */}
                  <motion.button
                    onClick={() => {
                      setIsOpen(false);
                      handleOpenPhoto();
                    }}
                    initial={{ opacity: 0, x: 30 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: navLinks.length * 0.05 }}
                    className="w-full text-lg font-serif font-bold text-navy hover:text-purple-700 transition-colors flex items-center justify-between py-3 px-4 rounded-xl hover:bg-purple-50 group text-left cursor-pointer"
                    id="drawer-photo-link"
                  >
                    <span className="flex items-center gap-1">
                      <span>Photo</span> <span className="text-xs">📷</span>
                    </span>
                    <span className="text-navy/30 group-hover:text-purple-700 font-sans font-normal text-sm transition-transform group-hover:translate-x-1">→</span>
                  </motion.button>
                </nav>
              </div>
              <div className="flex flex-col gap-4 border-t border-navy/5 pt-4">
                <div className="text-center text-xs font-mono text-charcoal pb-4">
                  Rutvik Dangar © 2026
                </div>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* Professional Photo Modal Frame */}
      <ProfessionalPhotoModal 
        isOpen={isPhotoOpen} 
        onClose={() => setIsPhotoOpen(false)} 
        sessionCount={sessionPhotoViews} 
      />
    </>
  );
}
