import { initializeApp } from 'firebase/app';
import { getFirestore, enableIndexedDbPersistence } from 'firebase/firestore';
import { getAuth } from 'firebase/auth';
import firebaseConfig from '../../firebase-applet-config.json';
import { useState, useEffect } from 'react';
import { doc, onSnapshot } from 'firebase/firestore';

// Initialize Firebase
const app = initializeApp(firebaseConfig);

// Initialize Firestore with specific databaseId provided dynamically
export const db = getFirestore(app, firebaseConfig.firestoreDatabaseId);

enableIndexedDbPersistence(db).catch((err) => {
  if (err.code == 'failed-precondition') {
      console.warn('Multiple tabs open, persistence can only be enabled in one tab at a time.');
  } else if (err.code == 'unimplemented') {
      console.warn('The current browser does not support all of the features required to enable persistence');
  }
});

export interface ProfileData {
  name: string;
  title: string;
  bio: string;
  photoUrl: string;
}

export const DEFAULT_PROFILE: ProfileData = {
  name: "Rutvik Dangar",
  title: "MARKETING × AI × NO-CODE CONSULTANT",
  bio: "Bridging the potential of cutting-edge AI orchestration with modern, high-conversion growth growth marketing and robust no-code architectures built for high impact.",
  photoUrl: "/rutvik_photo.jpg"
};

export function useProfile() {
  const [profile, setProfile] = useState<ProfileData>(DEFAULT_PROFILE);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const docRef = doc(db, "settings", "profile");
    const unsub = onSnapshot(docRef, (snap) => {
      if (snap.exists()) {
        const data = snap.data();
        setProfile({
          name: data.name || DEFAULT_PROFILE.name,
          title: data.title || DEFAULT_PROFILE.title,
          bio: data.bio || DEFAULT_PROFILE.bio,
          photoUrl: data.photoUrl || DEFAULT_PROFILE.photoUrl
        });
      } else {
        setProfile(DEFAULT_PROFILE);
      }
      setLoading(false);
    }, (err) => {
      console.warn("Error listening to profile settings, using fallback:", err);
      setProfile(DEFAULT_PROFILE);
      setLoading(false);
    });

    return unsub;
  }, []);

  return { profile, loading };
}

// Firestore Error Diagnostic Integration Helper
export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  }
}

export function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null): never {
  let userId: string | null = null;
  let email: string | null = null;
  let emailVerified: boolean | null = null;
  let isAnonymous: boolean | null = null;
  let tenantId: string | null = null;
  let providerInfo: any[] = [];

  try {
    const auth = getAuth(app);
    if (auth && auth.currentUser) {
      userId = auth.currentUser.uid;
      email = auth.currentUser.email;
      emailVerified = auth.currentUser.emailVerified;
      isAnonymous = auth.currentUser.isAnonymous;
      tenantId = auth.currentUser.tenantId;
      providerInfo = auth.currentUser.providerData?.map((provider: any) => ({
        providerId: provider.providerId,
        email: provider.email,
      })) || [];
    }
  } catch (e) {
    // Auth issue or uninitialized, keep defaults
  }

  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId,
      email,
      emailVerified,
      isAnonymous,
      tenantId,
      providerInfo
    },
    operationType,
    path
  };

  const stringifiedError = JSON.stringify(errInfo);
  console.error('Firestore Error: ', stringifiedError);
  throw new Error(stringifiedError);
}
