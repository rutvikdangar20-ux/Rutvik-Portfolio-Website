import React from "react";
import { motion } from "motion/react";
import { Sparkles, Trophy, Flame, ChevronRight } from "lucide-react";

export default function GlowingFinishingSlide() {
  const pillars = [
    {
      icon: <Sparkles className="text-amber-400" size={24} />,
      title: "Marketing Engineering",
      desc: "Creating conversion-optimized funnels, smart email marketing architectures, and data-driven growth strategies.",
      glow: "rgba(245, 158, 11, 0.15)",
      borderGlow: "hover:border-amber-500/50"
    },
    {
      icon: <Flame className="text-rose-500" size={24} />,
      title: "No-Code & Web Design",
      desc: "Architecting interactive, ultra-fast custom portfolios and product landing pages using modern Web builders.",
      glow: "rgba(244, 63, 94, 0.15)",
      borderGlow: "hover:border-rose-500/50"
    },
    {
      icon: <Trophy className="text-electric animate-pulse" size={24} />,
      title: "AI Integration & Workflows",
      desc: "Embedding Large Language Models and automated AI voice/chat agents directly into business systems.",
      glow: "rgba(37, 99, 235, 0.15)",
      borderGlow: "hover:border-blue-500/50"
    },
  ];

  return (
    <section 
      id="vision-synergy" 
      className="relative bg-[#020107] text-white py-32 px-6 overflow-hidden flex flex-col items-center justify-center border-t border-white/5"
    >
      {/* Dynamic ultra-visible premium ambient backgrounds */}
      <div className="absolute inset-0 z-0 pointer-events-none">
        <div className="absolute bottom-1/4 left-1/10 w-96 h-96 bg-electric/25 rounded-full blur-[140px]" />
        <div className="absolute top-1/4 right-1/10 w-[450px] h-[450px] bg-purple-500/22 rounded-full blur-[160px]" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-80 h-80 bg-gold/15 rounded-full blur-[120px]" />
      </div>

      <div className="relative z-10 max-w-5xl mx-auto w-full text-center">
        {/* Decorative Top Accent Tag */}
        <motion.div 
          initial={{ opacity: 0, y: 15 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-white/5 border border-white/10 text-xs text-electric font-mono uppercase tracking-widest mb-8"
        >
          <span className="relative flex h-2 w-2">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-electric opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2 w-2 bg-electric"></span>
          </span>
          Next Horizon
        </motion.div>

        {/* Display Typography Header */}
        <motion.h2 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7, delay: 0.1 }}
          className="text-4xl md:text-6xl font-serif font-bold tracking-tight text-white mb-6 leading-tight max-w-4xl mx-auto"
        >
          Translating Bold Visions Into <span className="text-transparent bg-clip-text bg-gradient-to-r from-electric via-purple-400 to-amber-300">Unmatched Realities</span>
        </motion.h2>

        <motion.p 
          initial={{ opacity: 0, y: 15 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7, delay: 0.2 }}
          className="text-white/60 text-lg md:text-xl max-w-2xl mx-auto mb-16 leading-relaxed"
        >
          I thrive at the intersection of creation and execution. This is only the beginning—every project is designed to break standards and define new limits. Let's create something landmark together.
        </motion.p>

        {/* Bento Grid layout with custom glows & border highlights */}
        <div className="grid md:grid-cols-3 gap-8 text-left mb-16">
          {pillars.map((pillar, i) => (
            <motion.div
              key={pillar.title}
              initial={{ opacity: 0, y: 25 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-50px" }}
              transition={{ duration: 0.6, delay: 0.1 * i }}
              whileHover={{ y: -8, scale: 1.02 }}
              style={
                {
                  "--glow-color": pillar.glow,
                } as React.CSSProperties
              }
              className={`p-8 rounded-2xl bg-white/[0.03] border border-white/10 hover:bg-white/[0.05] transition-all duration-300 relative group overflow-hidden ${pillar.borderGlow} cursor-default`}
            >
              {/* Radial inner glow highlight */}
              <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500 bg-[radial-gradient(400px_at_50%_-20px,var(--glow-color),transparent_100%)] pointer-events-none" />
              
              <div className="w-12 h-12 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                {pillar.icon}
              </div>

              <h3 className="text-xl font-bold font-sans text-white mb-3 tracking-tight">
                {pillar.title}
              </h3>

              <p className="text-sm text-white/55 leading-relaxed">
                {pillar.desc}
              </p>
            </motion.div>
          ))}
        </div>

        {/* Finishing Golden Call to Action & Sparkle Indicator */}
        <motion.div 
          initial={{ opacity: 0, scale: 0.95 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, delay: 0.4 }}
          className="relative inline-block group"
        >
          {/* Pulsing neon finishing outer shadow */}
          <div className="absolute -inset-1 rounded-full bg-gradient-to-r from-electric via-purple-500 to-amber-400 blur-xl opacity-30 group-hover:opacity-70 transition-opacity duration-500 animate-pulse" />
          
          <button 
            onClick={() => {
              // 1. Immediately launch rocket animation locally and increment Firestore counter
              window.dispatchEvent(new CustomEvent("launch-rocket"));
              
              // 2. Wait exactly 1 second (as the rocket leaves the viewport) to scroll up to Contact section
              setTimeout(() => {
                const lenis = (window as any).lenisInstance;
                const contactSec = document.getElementById("contact");
                if (lenis && contactSec) {
                  lenis.scrollTo(contactSec, { duration: 1.6, offset: -60 });
                } else if (contactSec) {
                  contactSec.scrollIntoView({ behavior: "smooth" });
                }
              }, 1000);
            }}
            className="relative px-12 py-5.5 bg-[#030712] border-2 border-white/60 hover:border-white text-white font-black text-lg rounded-full flex items-center gap-3.5 shadow-[0_0_40px_rgba(255,255,255,0.1)] transition-all hover:scale-105 active:scale-98 cursor-pointer select-none"
          >
            Launch Conversation 
            <ChevronRight className="text-electric group-hover:translate-x-2 transition-transform" size={20} />
          </button>
        </motion.div>
      </div>

      {/* Finishing Bottom Dividing Neon Line */}
      <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-4/5 h-[1px] bg-gradient-to-r from-transparent via-electric/30 to-transparent" />
    </section>
  );
}
