import React, { useState, useEffect, useRef } from "react";
import {
  MessageSquare,
  X,
  Send,
  Bot,
  Sparkles,
  Paperclip,
  Trash2,
  RotateCcw,
  MoreVertical,
  Image as ImageIcon,
  Settings,
  Share2,
  FileText,
} from "lucide-react";
import Markdown from "react-markdown";
import remarkGfm from "remark-gfm";
import TextareaAutosize from "react-textarea-autosize";
import { motion, AnimatePresence } from "framer-motion";
import { audioSynth } from "../utils/audio";
import { useProfile } from "./firebase";


type Message = {
  id: string;
  role: "user" | "ai";
  text: string;
  image?: string;
};

const SECTION_SUGGESTIONS: Record<string, string[]> = {
  hero: [
    "Who is Rutvik?",
    "What are his main skills?",
    "Where is he studying?",
  ],
  about: [
    "Tell me more about his background",
    "What is his edge?",
    "Where is he based?",
  ],
  projects: [
    "What is ANANTA?",
    "How does MileCharge work?",
    "Tell me about the fast food startup",
  ],
  academics: [
    "What is his BRM thesis about?",
    "What did he learn in Sem 3?",
    "Tell me about the CLASM data project",
  ],
  visits: [
    "What did he learn at Amul?",
    "Tell me about his visit to Adani Ports",
    "What did he do at Electrotherm?",
  ],
  skills: [
    "What are his core marketing skills?",
    "What UI/UX tools does he use?",
    "Is he experienced with data analysis?",
  ],
  tools: [
    "How does he use Claude?",
    "What does he build with OutSystems?",
    "Why does he use Framer?",
  ],
  insights: [
    "What is his opinion on No-Code?",
    "Tell me about the Omnichannel post",
    "What are his thoughts on AI trends?",
  ],
  contact: [
    "What is his email address?",
    "Does he have a LinkedIn?",
    "Is he open to internships?",
  ],
  default: [
    "Who is Rutvik?",
    "What projects has he built?",
    "What is ANANTA?",
    "How can I contact him?",
  ],
};

const sanitizeText = (text: string): string => {
  if (!text) return "";
  let cleaned = text.trim();
  if (cleaned.startsWith('"') && cleaned.endsWith('"')) {
    cleaned = cleaned.substring(1, cleaned.length - 1);
  }
  return cleaned
    .replace(/""/g, '"') // Replace redundant double quotes with single quotes
    .trim();
};

class SafeMarkdownRenderer extends React.Component<{ text: string; role: "user" | "ai" }, { hasError: boolean }> {
  constructor(props: any) {
    super(props);
    this.state = { hasError: false };
  }

  static getDerivedStateFromError() {
    return { hasError: true };
  }

  componentDidCatch(error: any, errorInfo: any) {
    console.error("Markdown rendering crashed:", error, errorInfo);
  }

  render() {
    if (this.state.hasError) {
      return (
        <span className="text-red-500 font-semibold text-sm">
          ⚠️ Formatting error: could not display response correctly.
        </span>
      );
    }

    try {
      const isAI = this.props.role === "ai";
      const content = isAI ? sanitizeText(this.props.text) : this.props.text;
      if (!content) return null;

      return (
        <Markdown remarkPlugins={[remarkGfm]}>
          {content}
        </Markdown>
      );
    } catch (err) {
      return (
        <span className="text-red-500 font-semibold text-sm">
          ⚠️ Formatting error: could not display response correctly.
        </span>
      );
    }
  }
}

const QUICK_CLICKS = [
  {
    icon: "💼",
    title: "Rutvik's Projects",
    desc: "Explore his key AI & Marketing projects",
    query: "What major projects has Rutvik built in his portfolio?"
  },
  {
    icon: "🎓",
    title: "Academic Background",
    desc: "BBA honours & business research studies",
    query: "Tell me about Rutvik's academic research and studies at AIBM."
  },
  {
    icon: "⚡",
    title: "AI Integrations",
    desc: "How he builds and connects AI models",
    query: "How does Rutvik leverage artificial intelligence in his projects and website portfolio?"
  },
  {
    icon: "📞",
    title: "Contact & Connect",
    desc: "Internships, social media, and hiring info",
    query: "How can I contact Rutvik and find his social media profiles?"
  }
];

const INITIAL_MESSAGE =
  "Hi there! I'm Rutvik's AI assistant. I have complete knowledge of his academic journey, marketing strategies, industry visits, and AI projects. How can I help you learn more about his work today?";

export default function Chatbot() {
  const { profile } = useProfile();
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    { id: "1", role: "ai", text: INITIAL_MESSAGE },
  ]);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [showOptions, setShowOptions] = useState(false);
  const [confirmDialog, setConfirmDialog] = useState<"reset" | "delete" | null>(
    null,
  );

  const [activeSection, setActiveSection] = useState("default");
  const [floatingSuggestion, setFloatingSuggestion] = useState("");

  const [file, setFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);

  const [isAdminOpen, setIsAdminOpen] = useState(false);
  const [adminInstructions, setAdminInstructions] = useState("");
  const [progress, setProgress] = useState(0);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const adminClickCountRef = useRef(0);
  const adminTimerRef = useRef<NodeJS.Timeout | null>(null);
  const adminSoundTimerRef = useRef<NodeJS.Timeout | null>(null);
  const adminOpenTimerRef = useRef<NodeJS.Timeout | null>(null);

  const handleAdminClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    
    if (adminTimerRef.current) {
      clearTimeout(adminTimerRef.current);
      adminTimerRef.current = null;
    }

    adminClickCountRef.current += 1;

    if (adminClickCountRef.current >= 2) {
      if (adminSoundTimerRef.current) {
        clearTimeout(adminSoundTimerRef.current);
        adminSoundTimerRef.current = null;
      }
      if (adminOpenTimerRef.current) {
        clearTimeout(adminOpenTimerRef.current);
        adminOpenTimerRef.current = null;
      }
      adminClickCountRef.current = 0;
      showToast("Access denined: double click detected ❌");
      setShowOptions(false);
      return;
    }

    adminTimerRef.current = setTimeout(() => {
      adminClickCountRef.current = 0;

      showToast("Access requested... ⏳");
      
      // Plop sound (pani ki bund) after 1st second (1000ms)
      adminSoundTimerRef.current = setTimeout(() => {
        audioSynth.playWaterDrop();
      }, 1000);

      // Open Admin control panel after 2nd second (2000ms)
      adminOpenTimerRef.current = setTimeout(() => {
        setIsAdminOpen(true);
        setShowOptions(false);
      }, 2000);
    }, 250);
  };

  useEffect(() => {
    // Clean up admin timers on unmount
    return () => {
      if (adminTimerRef.current) clearTimeout(adminTimerRef.current);
      if (adminSoundTimerRef.current) clearTimeout(adminSoundTimerRef.current);
      if (adminOpenTimerRef.current) clearTimeout(adminOpenTimerRef.current);
    };
  }, []);

  useEffect(() => {
    const handleToggle = () => {
      setIsOpen((prev) => !prev);
    };
    window.addEventListener("toggle-chatbot", handleToggle);
    return () => {
      window.removeEventListener("toggle-chatbot", handleToggle);
    };
  }, []);

  useEffect(() => {
    const handleScroll = () => {
      const sections = document.querySelectorAll("section[id]");
      let currentSection = "default";

      sections.forEach((section) => {
        const rect = section.getBoundingClientRect();
        if (
          rect.top <= window.innerHeight / 2 &&
          rect.bottom >= window.innerHeight / 2
        ) {
          currentSection = section.id;
        }
      });

      setActiveSection(currentSection);
    };

    window.addEventListener("scroll", handleScroll);
    handleScroll();

    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  useEffect(() => {
    const suggestions = SECTION_SUGGESTIONS[activeSection] || SECTION_SUGGESTIONS.default;
    if (suggestions && suggestions.length > 0) {
      setFloatingSuggestion(suggestions[0]);
    }
  }, [activeSection]);

  // Rotate suggestions every 8 seconds
  useEffect(() => {
    const timer = setInterval(() => {
      const suggestions = SECTION_SUGGESTIONS[activeSection] || SECTION_SUGGESTIONS.default;
      if (suggestions && suggestions.length > 1) {
        setFloatingSuggestion((prev) => {
          const idx = suggestions.indexOf(prev);
          const nextIdx = (idx + 1) % suggestions.length;
          return suggestions[nextIdx];
        });
      }
    }, 8000);
    return () => clearInterval(timer);
  }, [activeSection]);

  useEffect(() => {
    const saved = localStorage.getItem("rutvik_chat_history");
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (parsed.length > 0) setMessages(parsed);
      } catch (e) {
        // ignore
      }
    }
    const savedAdmin = localStorage.getItem("rutvik_admin_instructions");
    if (savedAdmin) {
      setAdminInstructions(savedAdmin);
    }
  }, []);

  useEffect(() => {
    try {
      localStorage.setItem("rutvik_chat_history", JSON.stringify(messages));
    } catch (e) {
      console.warn("Could not save to localStorage, likely due to size limits.");
    }
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, isOpen]);

  const saveAdminInstructions = () => {
    localStorage.setItem("rutvik_admin_instructions", adminInstructions);
    setIsAdminOpen(false);
    setShowOptions(false);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selected = e.target.files?.[0];
    if (selected) {
      setFile(selected);
      const reader = new FileReader();
      reader.onloadend = () => {
        setPreviewUrl(reader.result as string);
      };
      reader.readAsDataURL(selected);
    }
    if (fileInputRef.current) fileInputRef.current.value = "";
  };

  const handleShare = async () => {
    try {
      if (navigator.share) {
        await navigator.share({
          title: "Rutvik Dangar Space",
          text: "Check out Rutvik Dangar's portfolio and chat with this awesome AI agent! 🚀",
          url: "https://rutvikinfo-web-com.vercel.app"
        });
      } else {
        await navigator.clipboard.writeText("https://rutvikinfo-web-com.vercel.app");
        alert("Link copied to clipboard!");
      }
    } catch (err) {
      console.log("Error sharing:", err);
    }
  };

  const removeFile = () => {
    setFile(null);
    setPreviewUrl(null);
  };

  const resetChat = () => {
    localStorage.removeItem("rutvik_chat_history");
    setMessages([
      { id: Date.now().toString(), role: "ai", text: INITIAL_MESSAGE },
    ]);
    setConfirmDialog(null);
    setShowOptions(false);
    showToast("Conversation reset successfully!");
  };

  const deleteChat = () => {
    localStorage.removeItem("rutvik_chat_history");
    setMessages([
      { id: Date.now().toString(), role: "ai", text: INITIAL_MESSAGE },
    ]);
    setConfirmDialog(null);
    setShowOptions(false);
    setIsOpen(false);
    showToast("Conversation deleted successfully!");
  };

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  const handleSend = async (text: string) => {
    if (!text.trim() && !file) return;

    const userMsg: Message = {
      id: Date.now().toString(),
      role: "user",
      text,
      image: previewUrl || undefined,
    };

    // Convert to history format backend expects
    const currentHist = [...messages].map((m) => ({
      role: m.role,
      text: m.text,
    }));

    setMessages((prev) => [...prev, userMsg]);
    setInput("");
    
    // Capture file before removing it
    const fileBase64 = previewUrl;
    
    removeFile();
    setIsLoading(true);
    setProgress(0);

    const progressInterval = setInterval(() => {
      setProgress((prev) => (prev < 90 ? prev + Math.floor(Math.random() * 15) + 5 : 95));
    }, 400);

    let tempId: string | null = null;
    try {
      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          message: text || "User uploaded a file.",
          history: currentHist,
          adminInstructions,
          image: fileBase64 || undefined,
        }),
      });

      clearInterval(progressInterval);
      setProgress(100);

      if (!res.ok) {
        let fallbackMessage = "Connection error. Please try again later.";
        try {
          const errData = await res.json();
          if (errData.error) {
            fallbackMessage = errData.error;
          }
        } catch (_) {
          try {
            const rawText = await res.text();
            if (rawText) fallbackMessage = rawText;
          } catch (__) {}
        }
        throw new Error(fallbackMessage);
      }

      const reader = res.body?.getReader();
      const decoder = new TextDecoder("utf-8");

      if (!reader) {
        throw new Error("No body reader available for streaming.");
      }

      tempId = Date.now().toString();
      setMessages((prev) => [
        ...prev,
        { id: tempId!, role: "ai", text: "" },
      ]);

      let accumulatedText = "";
      while (true) {
        let result: ReadableStreamReadResult<Uint8Array>;
        try {
          result = await reader.read();
        } catch (readErr: any) {
          throw new Error(`Connection lost while receiving response: ${readErr?.message || "Stream interrupted"}`);
        }

        const { done, value } = result;
        if (done) break;

        const chunkText = decoder.decode(value, { stream: true });
        accumulatedText += chunkText;

        if (accumulatedText.includes("[ERROR]:")) {
          const parts = accumulatedText.split("[ERROR]:");
          accumulatedText = parts[0] + "\n\n⚠️ " + (parts[1] || "An error occurred.");
        }

        setMessages((prev) =>
          prev.map((m) => (m.id === tempId ? { ...m, text: accumulatedText } : m))
        );
      }

      if (!accumulatedText.trim()) {
        throw new Error("Empty or null response received from the AI assistant.");
      }
    } catch (err: any) {
      clearInterval(progressInterval);
      const errorMessage = err?.message || "Connection error. Please try again later.";
      
      if (tempId) {
        // If we created a placeholder message, update it with the error message
        setMessages((prev) =>
          prev.map((m) => (m.id === tempId ? { ...m, text: `⚠️ ${errorMessage}` } : m))
        );
      } else {
        // Otherwise, append a new error message
        setMessages((prev) => [
          ...prev,
          {
            id: Date.now().toString(),
            role: "ai",
            text: `⚠️ ${errorMessage}`,
          },
        ]);
      }
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <>
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[9000] flex items-center justify-center p-4"
          >
            {/* Backdrop Blur Overlay with click handling */}
            <div
              onClick={() => {
                audioSynth.playCloseSwell();
                setIsOpen(false);
              }}
              className="absolute inset-0 bg-navy/60 backdrop-blur-sm cursor-pointer"
            />

            {/* Centered Modal Container */}
            <motion.div
              initial={{ opacity: 0, scale: 0.9, y: 30 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 30 }}
              transition={{ type: "spring", stiffness: 300, damping: 24 }}
              className="relative w-full max-w-[485px] h-[660px] max-h-[85vh] bg-white rounded-3xl shadow-3xl flex flex-col z-10 overflow-hidden border border-navy/10"
              data-lenis-prevent
            >
            {/* Header */}
            <div className="bg-navy p-4 flex items-center justify-between shadow-md relative z-20">
              <div className="flex items-center gap-3">
                <button
                  onClick={() => {
                    audioSynth.playClick();
                    window.dispatchEvent(new CustomEvent("open-photo-modal"));
                  }}
                  className="w-10 h-10 rounded-full bg-gradient-to-tr from-sky-400 via-[#a855f7] to-rose-400 p-[1.5px] hover:scale-105 active:scale-95 transition-all cursor-pointer relative shadow-[0_0_15px_rgba(168,85,247,0.5)] border border-white/20 shrink-0 flex items-center justify-center group"
                  title="View Rutvik's Professional Photo 📷"
                >
                  <div className="w-full h-full rounded-full bg-navy overflow-hidden relative flex items-center justify-center">
                    <img 
                      src={profile.photoUrl} 
                      alt="Rutvik" 
                      className="w-full h-full object-cover object-[center_12%] scale-[2.2] translate-y-[15%] group-hover:brightness-110 group-hover:scale-[2.4] transition-all pointer-events-none"
                      referrerPolicy="no-referrer"
                    />
                  </div>
                  <div className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 rounded-full border-2 border-navy"></div>
                </button>
                <div>
                  <h3 className="text-white font-bold text-sm">
                    Rutvik's AI Agent
                  </h3>
                  <p className="text-electric text-xs flex items-center gap-1">
                    <Sparkles size={18} /> Always Online
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-2 relative">
                <button
                  onClick={() => {
                    audioSynth.playClick();
                    handleShare();
                  }} className="text-white/70 hover:text-white transition-colors p-2 rounded-full hover:bg-white/10"
                  aria-label="Share"
                >
                  <Share2 size={18} />
                </button>
                <button
                  onClick={() => {
                    audioSynth.playClick();
                    setShowOptions(!showOptions);
                  }}
                  className="text-white/70 hover:text-white transition-colors p-2 rounded-full hover:bg-white/10"
                >
                  <MoreVertical size={18} />
                </button>
                <button
                  onClick={() => {
                    audioSynth.playCloseSwell();
                    setIsOpen(false);
                  }}
                  className="text-white/70 hover:text-white transition-colors p-2 rounded-full hover:bg-white/10"
                >
                  <X size={18} />
                </button>

                {/* Options Dropdown */}
                
                  {showOptions && (
                    <div   className="absolute right-0 top-12 bg-white rounded-xl shadow-xl border border-navy/10 py-2 w-40 z-50" >
                      <button
                        onClick={() => setConfirmDialog("reset")}
                        className="w-full text-left px-4 py-2 text-sm text-charcoal hover:bg-cream flex items-center gap-2 transition-colors"
                      >
                        <RotateCcw size={18} /> Reset Chat
                      </button>
                      <button
                        onClick={() => setConfirmDialog("delete")}
                        className="w-full text-left px-4 py-2 text-sm text-red-600 hover:bg-red-50 flex items-center gap-2 transition-colors"
                      >
                        <Trash2 size={18} /> Delete Chat
                      </button>
                      <button
                        onClick={handleAdminClick}
                        className="w-full text-left px-4 py-2 text-sm text-charcoal hover:bg-cream flex items-center gap-2 transition-colors"
                      >
                        <Settings size={18} /> Admin Panel
                      </button>
                    </div>
                  )}
              </div>
            </div>

            {/* Admin Panel Overlay */}
              {isAdminOpen && (
                <div className="absolute inset-0 bg-navy/60 backdrop-blur-md z-40 flex items-center justify-center p-4 rounded-3xl">
                  <div className="bg-white rounded-2xl p-5 shadow-2xl max-w-sm w-full flex flex-col h-[80%]">
                    <div className="flex justify-between items-center mb-4">
                      <h3 className="font-bold text-navy flex items-center gap-2">
                        <Settings size={18} className="text-electric" /> Admin Setup
                      </h3>
                      <button
                        onClick={() => setIsAdminOpen(false)}
                        className="text-charcoal hover:text-navy"
                      >
                        <X size={18} />
                      </button>
                    </div>
                    <p className="text-xs text-charcoal mb-3">
                      Update the chatbot's knowledge base securely here.
                    </p>
                    <textarea
                      className="flex-1 w-full border border-navy/10 rounded-xl p-3 text-sm resize-none focus:outline-none focus:ring-2 focus:ring-electric/30 mb-4 bg-cream/30"
                      placeholder="e.g. Rutvik recently won a hackathon..."
                      value={adminInstructions}
                      onChange={(e) => setAdminInstructions(e.target.value)}
                    ></textarea>
                    <button
                      onClick={() => {
                        localStorage.setItem("rutvik_admin_instructions", adminInstructions);
                        setIsAdminOpen(false);
                      }}
                      className="w-full py-2.5 rounded-xl bg-navy text-white font-bold text-sm hover:bg-electric transition-colors"
                    >
                      Save Knowledge
                    </button>
                  </div>
                </div>
              )}

            {/* Confirmation Dialog overlay rendered Inline */}
            {confirmDialog && (
              <div className="fixed inset-0 bg-navy/40 backdrop-blur-sm z-[9999] flex items-center justify-center p-4">
                <div className="bg-white rounded-2xl p-6 shadow-xl w-full max-w-sm border border-navy/10 relative">
                  <h4 className="font-bold text-navy text-lg mb-2">
                    {confirmDialog === "reset"
                      ? "Reset Conversation?"
                      : "Delete Conversation?"}
                  </h4>
                  <p className="text-charcoal text-sm mb-6">
                    Are you sure you want to{" "}
                    {confirmDialog === "reset" ? "clear" : "delete"} all
                    existing messages? This action cannot be undone.
                  </p>
                  <div className="flex gap-3 justify-end">
                    <button
                      onClick={() => setConfirmDialog(null)}
                      className="px-4 py-2 text-sm font-medium text-navy hover:bg-cream rounded-lg transition-colors border border-navy/10"
                    >
                      Cancel
                    </button>
                    <button
                      onClick={
                        confirmDialog === "reset" ? resetChat : deleteChat
                      }
                      className="px-4 py-2 text-sm font-bold text-white bg-red-500 hover:bg-red-600 rounded-lg transition-colors shadow-sm"
                    >
                      Confirm
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* Toast Notification rendered Inline */}
            {toastMessage && (
              <div style={{ transform: "translateX(-50%)" }} className="fixed bottom-10 left-1/2 z-[10000] bg-navy text-white px-6 py-3 rounded-full shadow-lg font-medium text-sm flex items-center gap-2">
                <Sparkles size={18} className="text-electric" />
                {toastMessage}
              </div>
            )}

            {/* Messages Area */}
            <div
              className="flex-1 overflow-y-auto p-4 md:p-6 bg-[#f8f9fa] space-y-6"
              onClick={() => setShowOptions(false)}
              data-lenis-prevent
            >
              {messages.map((msg, index) => (
                <div key={index} className={`flex w-full ${msg.role === "user" ? "justify-end" : "justify-start"}`}>
                  {msg.role === "ai" && (
                    <button
                      onClick={() => {
                        audioSynth.playClick();
                        window.dispatchEvent(new CustomEvent("open-photo-modal"));
                      }}
                      className="w-8 h-8 rounded-full bg-gradient-to-tr from-sky-400 via-[#a855f7] to-rose-400 p-[1px] hover:scale-105 active:scale-95 transition-all cursor-pointer shadow-[0_0_8px_rgba(168,85,247,0.4)] border border-white/10 overflow-hidden shrink-0 mr-3 mt-1 flex items-center justify-center group"
                      title="View Rutvik's Professional Photo 📷"
                    >
                      <div className="w-full h-full rounded-full bg-navy overflow-hidden relative flex items-center justify-center">
                        <img 
                          src={profile.photoUrl} 
                          alt="Rutvik" 
                          className="w-full h-full object-cover object-[center_12%] scale-[2.2] translate-y-[15%] group-hover:brightness-110 group-hover:scale-[2.4] transition-all pointer-events-none"
                          referrerPolicy="no-referrer"
                        />
                      </div>
                    </button>
                  )}
                  <div
                    className={`max-w-[80%] rounded-2xl p-4 ${msg.role === "user" ? "bg-navy text-white rounded-tr-sm shadow-md" : "bg-white border border-black/5 text-charcoal rounded-tl-sm shadow-sm"}`}>
                    {msg.image && (
                      <div className="mb-3 rounded-xl overflow-hidden relative group">
                        {msg.image.startsWith("data:image/") ? (
                          <img
                            src={msg.image}
                            alt="Upload preview"
                            className="w-full h-auto object-cover max-h-48 bg-white"
                          />
                        ) : (
                          <div className="w-full h-24 bg-white/10 flex items-center justify-center gap-2 border border-white/20 rounded-xl">
                            <FileText size={18} className="text-white/80" />
                            <span className="text-sm font-medium text-white/80">Document Attached</span>
                          </div>
                        )}
                      </div>
                    )}
                    {msg.text && (
                      <div className={`text-[15px] prose prose-sm prose-p:leading-relaxed prose-a:text-electric prose-strong:text-current font-sans ${msg.role === "user" ? "text-white prose-invert" : "text-charcoal"}`}>
                        <SafeMarkdownRenderer text={msg.text} role={msg.role} />
                      </div>
                    )}
                    {index === 0 && messages.length === 1 && (
                      <div className="mt-4 pt-4 border-t border-navy/5">
                        <p className="text-[11px] font-bold text-navy/40 uppercase tracking-widest mb-3">Quick Suggestions (QCL):</p>
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                          {QUICK_CLICKS.map((click, idx) => (
                            <button
                              key={idx}
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                audioSynth.playClick();
                                handleSend(click.query);
                              }}
                              className="text-left p-3 rounded-xl bg-cream/30 hover:bg-cream border border-navy/5 hover:border-electric/30 transition-all shadow-sm flex flex-col justify-between group cursor-pointer"
                            >
                              <div className="flex items-center gap-2 mb-1.5">
                                <span className="text-sm group-hover:scale-110 transition-transform">{click.icon}</span>
                                <span className="text-xs font-bold text-navy">{click.title}</span>
                              </div>
                              <p className="text-[10px] text-charcoal/70 line-clamp-2 leading-relaxed">{click.desc}</p>
                            </button>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              ))}
              {isLoading && (
                <div className="flex w-full justify-start items-center">
                  <button
                    onClick={() => {
                      audioSynth.playClick();
                      window.dispatchEvent(new CustomEvent("open-photo-modal"));
                    }}
                    className="w-8 h-8 rounded-full bg-gradient-to-tr from-sky-400 via-[#a855f7] to-rose-400 p-[1px] hover:scale-105 active:scale-95 transition-all cursor-pointer shadow-[0_0_8px_rgba(168,85,247,0.4)] border border-white/10 overflow-hidden shrink-0 mr-3 flex items-center justify-center group"
                    title="View Rutvik's Professional Photo 📷"
                  >
                    <div className="w-full h-full rounded-full bg-navy overflow-hidden relative flex items-center justify-center">
                      <img 
                        src={profile.photoUrl} 
                        alt="Rutvik" 
                        className="w-full h-full object-cover object-[center_12%] scale-[2.2] translate-y-[15%] group-hover:brightness-110 group-hover:scale-[2.4] transition-all pointer-events-none"
                        referrerPolicy="no-referrer"
                      />
                    </div>
                  </button>
                  <div className="bg-white border border-black/5 px-4 py-3 rounded-2xl rounded-tl-sm flex gap-3 items-center shadow-sm relative overflow-hidden min-w-[200px]">
                    <div className="absolute left-0 top-0 bottom-0 bg-electric/5 transition-all duration-300 ease-out" 
                      style={{ width: `${progress}%` }}></div>
                    
                    <div className="relative w-5 h-5 shrink-0 flex items-center justify-center">
                      <svg className="w-full h-full -rotate-90 transform" viewBox="0 0 24 24">
                        <circle
                          cx="12"
                          cy="12"
                          r="10"
                          stroke="currentColor"
                          strokeWidth="3"
                          fill="none"
                          className="text-navy/10"
                        />
                        <circle
                          cx="12"
                          cy="12"
                          r="10"
                          stroke="currentColor"
                          strokeWidth="3"
                          fill="none"
                          strokeLinecap="round"
                          className="text-electric animate-[spin_2s_linear_infinite]"
                          strokeDasharray={2 * Math.PI * 10}
                          strokeDashoffset={(2 * Math.PI * 10) * (1 - (progress / 100))}
                          style={{ transition: 'stroke-dashoffset 0.3s ease' }}
                        />
                      </svg>
                    </div>
                    
                    <div className="flex flex-col relative">
                      <span className="text-xs font-bold text-navy">
                        Analyzing
                      </span>
                      <span className="text-[10px] text-charcoal/70 font-medium tracking-wide">
                        {progress}% Complete
                      </span>
                    </div>
                  </div>
                </div>
              )}
              <div ref={messagesEndRef} className="h-2" />
            </div>

            {/* Input Area */}
            <div className="p-4 bg-white border-t border-navy/5 shadow-[0_-10px_30px_rgba(0,0,0,0.03)] z-10 relative">
              <div className="flex overflow-x-auto gap-2 mb-4 pb-2 items-center hide-scrollbar">
                {(
                  SECTION_SUGGESTIONS[activeSection] ||
                  SECTION_SUGGESTIONS.default
                ).map((sug, i) => (
                  <button
                    key={i}
                    onClick={() => {
                      audioSynth.playClick();
                      handleSend(sug);
                    }}
                    className="shrink-0 whitespace-nowrap text-xs bg-cream/70 border border-navy/10 text-navy font-medium px-4 py-2 rounded-full hover:bg-electric hover:text-white hover:border-electric transition-colors shadow-sm"
                  >
                    {sug}
                  </button>
                ))}
              </div>

              {/* File Preview */}
              
                {previewUrl && (
                  <div className="mb-3 relative inline-block">
                    <div className="relative group rounded-xl overflow-hidden border border-navy/10 w-24 h-24 bg-cream flex items-center justify-center shadow-sm">
                      {file?.type.startsWith("image/") ? (
                        <img
                          src={previewUrl}
                          alt="Preview"
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <ImageIcon className="text-navy" />
                      )}

                      <button
                        type="button"
                        onClick={() => {
                          audioSynth.playClick();
                          removeFile();
                        }} className="absolute top-1 right-1 w-6 h-6 bg-charcoal/80 text-white rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"
                      >
                        <X size={18} />
                      </button>
                    </div>
                  </div>
                )}
              

              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  audioSynth.playChime();
                  handleSend(input);
                }} className="flex items-end gap-2 bg-[#f4f4f5] rounded-2xl p-2 border border-black/5 focus-within:ring-2 focus-within:ring-electric/30 transition-shadow"
              >
                <div className="pb-1 pl-1">
                  <input
                    type="file"
                    className="hidden"
                    ref={fileInputRef}
                    onChange={handleFileChange}
                  />
                  <button
                    type="button"
                    onClick={() => {
                      audioSynth.playClick();
                      fileInputRef.current?.click();
                    }}
                    className="p-2 text-charcoal hover:text-navy hover:bg-black/5 rounded-full transition-colors flex shrink-0"
                    title="Upload File or Image"
                  >
                    <Paperclip size={18} />
                  </button>
                </div>

                <TextareaAutosize
                  minRows={1}
                  maxRows={5}
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter" && !e.shiftKey) {
                      e.preventDefault();
                      audioSynth.playChime();
                      handleSend(input);
                    }
                  }} placeholder="Ask anything about Rutvik..."
                  className="flex-1 bg-transparent px-2 py-2.5 resize-none focus:outline-none text-sm text-charcoal leading-snug self-center"
                  disabled={isLoading}
                />

                <div className="pb-1 pr-1">
                  <button
                    type="submit"
                    disabled={(!input.trim() && !file) || isLoading} className="w-9 h-9 bg-navy text-white rounded-full flex items-center justify-center hover:bg-electric transition-colors disabled:opacity-40 disabled:hover:bg-navy shrink-0 shadow-sm"
                  >
                    <Send size={18} className="ml-0.5" />
                  </button>
                </div>
              </form>
              <div className="text-center mt-3">
                <span className="text-[10px] text-charcoal font-medium tracking-wide uppercase">
                  AI assistants can make mistakes. Verify important info.
                </span>
              </div>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
      
    </>
  );
}
