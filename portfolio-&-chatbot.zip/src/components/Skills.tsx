import { useState, useEffect, useRef } from "react";
import { CheckCircle2, Target, Award, Sparkles, TrendingUp, Cpu, Network, BarChart3, HelpCircle, X } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import CountUp from "./CountUp";
import { audioSynth } from "../utils/audio";


interface SkillItem {
  title: string;
  category: "Technical" | "Strategy" | "Research" | "Design";
  level: number;
  desc: string;
  subAttributes: { name: string; value: number }[];
}

const getDynamicColor = (level: number) => {
  const ratio = Math.max(0, Math.min(100, level)) / 100;
  // Interpolating green (emerald-500: rgb(16, 185, 129)) to blue (blue-600: rgb(37, 99, 235))
  const r = Math.round(16 + (37 - 16) * ratio);
  const g = Math.round(185 + (99 - 185) * ratio);
  const b = Math.round(129 + (235 - 129) * ratio);
  return `rgb(${r}, ${g}, ${b})`;
};

export default function Skills() {
  const coreSkills: SkillItem[] = [
    {
      title: "Artificial Intelligence & Prompt Engineering",
      category: "Technical",
      level: 96,
      desc: "Architecting autonomous systems, crafting advanced chain-of-thought instructions, and orchestrating multimodal LLM APIs to drive operational automation.",
      subAttributes: [
        { name: "Complex Instructions", value: 98 },
        { name: "Agentic Workflows", value: 95 },
        { name: "API Integrations", value: 93 },
      ],
    },
    {
      title: "No-Code & Low-Code App Development",
      category: "Technical",
      level: 92,
      desc: "Combining OutSystems, n8n, and standard API services to spin up secure, fully transactional applications, speeding up MVP lifecycles.",
      subAttributes: [
        { name: "OutSystems Core", value: 94 },
        { name: "n8n Pipelines", value: 92 },
        { name: "API Connection", value: 90 },
      ],
    },
    {
      title: "Advanced Data Analysis (MS Excel)",
      category: "Technical",
      level: 90,
      desc: "Utilizing advanced nested logic, arrays, and customized pivot models to extract clean insights from unstructured corporate datasets.",
      subAttributes: [
        { name: "Pivot Architecture", value: 92 },
        { name: "Nested Formula Logic", value: 90 },
        { name: "Data Scrubbing & QC", value: 88 },
      ],
    },
    {
      title: "Digital Marketing & Marketing Strategy",
      category: "Strategy",
      level: 91,
      desc: "Devising metrics-focused marketing loops and programmatic B2B outreach blueprints that drive product adoption and customer loyalty.",
      subAttributes: [
        { name: "Growth Loops", value: 93 },
        { name: "B2B Lead gen", value: 91 },
        { name: "Campaign Modeling", value: 89 },
      ],
    },
    {
      title: "Product Design & Startup Planning",
      category: "Strategy",
      level: 89,
      desc: "Iterating from wireframes to release, validating product market fit, and structuring solid commercial schemas for startups.",
      subAttributes: [
        { name: "MVP Scoping", value: 91 },
        { name: "Unit Economics", value: 88 },
        { name: "Milestone Roadmapping", value: 88 },
      ],
    },
    {
      title: "Content Strategy & Copywriting",
      category: "Strategy",
      level: 88,
      desc: "Drafting high-conversion copies, designing brand guides, and implementing SEO-driven narratives that attract organic attention.",
      subAttributes: [
        { name: "Converting Copy", value: 91 },
        { name: "Brand Voice Mapping", value: 88 },
        { name: "SEO Ecosystems", value: 85 },
      ],
    },
    {
      title: "Social Media Marketing",
      category: "Strategy",
      level: 86,
      desc: "Orchestrating viral visual campaigns and configuring social analytics triggers to boost brand engagement organically.",
      subAttributes: [
        { name: "Organic Hook Loops", value: 89 },
        { name: "Engagement Funnels", value: 85 },
        { name: "Video Layout Logic", value: 84 },
      ],
    },
    {
      title: "Market Research & Consumer Behaviour",
      category: "Research",
      level: 87,
      desc: "Modeling qualitative feedback, tracking demographic purchase behaviors, and engineering actionable insights for development.",
      subAttributes: [
        { name: "User Psych Mapping", value: 89 },
        { name: "Interview Structuring", value: 86 },
        { name: "Competitive Auditing", value: 86 },
      ],
    },
    {
      title: "Business Research Methods (BRM)",
      category: "Research",
      level: 84,
      desc: "Employing rigorous statistical distributions, robust diagnostic criteria, and data triangulation methods to support decision integrity.",
      subAttributes: [
        { name: "Diagnostic Metrics", value: 86 },
        { name: "Survey Construction", value: 84 },
        { name: "Hypothesis Testing", value: 82 },
      ],
    },
    {
      title: "UI/UX Design Concept & Wireframing",
      category: "Design",
      level: 88,
      desc: "Drafting clean Figma mockups, tracing friction-free paths, and organizing layouts focusing on structural design symmetry.",
      subAttributes: [
        { name: "Figma Wireframes", value: 90 },
        { name: "User Flow Mapping", value: 88 },
        { name: "Visual Spec Sheets", value: 86 },
      ],
    },
  ];

  const categories = [
    { id: "all", name: "All Capabilities" },
    { id: "Technical", name: "Technical & AI" },
    { id: "Strategy", name: "Growth Strategy" },
    { id: "Research-Design", name: "Research & Design" },
  ];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.08,
      },
    },
  };

  const cardVariants = {
    hidden: { opacity: 0, y: 25, scale: 0.96 },
    visible: { 
      opacity: 1, 
      y: 0, 
      scale: 1,
      transition: {
        type: "spring" as const,
        stiffness: 90,
        damping: 15
      }
    },
  };

  const [activeCategory, setActiveCategory] = useState("all");
  const [selectedSkill, setSelectedSkill] = useState<SkillItem>(coreSkills[0]);
  const [isModalOpen, setIsModalOpen] = useState(false);

  const hasPlayedSoundRef = useRef(false);

  const playWhooshSound = () => {
    if (hasPlayedSoundRef.current) return;
    hasPlayedSoundRef.current = true;
    
    try {
      const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioContextClass) return;
      const ctx = new AudioContextClass();
      
      const duration = 0.55;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      const filter = ctx.createBiquadFilter();
      
      osc.type = "sine";
      osc.frequency.setValueAtTime(100, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(680, ctx.currentTime + duration);
      
      filter.type = "bandpass";
      filter.frequency.setValueAtTime(300, ctx.currentTime);
      filter.frequency.exponentialRampToValueAtTime(1100, ctx.currentTime + duration);
      filter.Q.setValueAtTime(2.5, ctx.currentTime);
      
      gain.gain.setValueAtTime(0.001, ctx.currentTime);
      gain.gain.linearRampToValueAtTime(0.05, ctx.currentTime + 0.15);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + duration);
      
      osc.connect(filter);
      filter.connect(gain);
      gain.connect(ctx.destination);
      
      osc.start(ctx.currentTime);
      osc.stop(ctx.currentTime + duration);
    } catch (e) {
      console.warn("Audio Context whoosh blocked or unsupported:", e);
    }
  };

  // Adjust selected skill when category changes to avoid choosing an item not in view
  useEffect(() => {
    const filtered = getFilteredSkills();
    if (filtered.length > 0 && !filtered.includes(selectedSkill)) {
      setSelectedSkill(filtered[0]);
    }
  }, [activeCategory]);

  function getFilteredSkills() {
    if (activeCategory === "all") return coreSkills;
    if (activeCategory === "Research-Design") {
      return coreSkills.filter((s) => s.category === "Research" || s.category === "Design");
    }
    return coreSkills.filter((s) => s.category === activeCategory);
  }

  const filteredSkills = getFilteredSkills();

  // For the circle gauge calculation
  const radius = 64;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - (selectedSkill.level / 100) * circumference;

  return (
    <section id="skills" className="py-24 px-6 relative bg-transparent overflow-hidden">
      {/* Background Decorative Accents */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden opacity-30">
        <div className="absolute -top-[10%] right-[15%] w-[400px] h-[400px] rounded-full bg-electric/5 blur-[120px]" />
        <div className="absolute bottom-[20%] left-[5%] w-[350px] h-[350px] rounded-full bg-indigo-500/5 blur-[100px]" />
      </div>

      <div className="max-w-6xl mx-auto relative z-10">
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 px-3 py-1 bg-navy/5 text-electric rounded-full text-xs font-bold tracking-wider uppercase mb-4 border border-navy/5">
            <Sparkles size={12} className="text-electric" /> Specialization Showcase
          </div>
          <h2 className="font-serif text-3xl md:text-5xl font-bold text-navy mb-4">
            Capabilities & Focus Areas
          </h2>
          <p className="text-charcoal/80 text-lg max-w-2xl mx-auto">
            Interactive diagnostic console exploring Rutvik's core strategic competencies, 
            analytical tools, and hands-on skill proficiencies. Tap any capability to view deep breakdown.
          </p>
        </div>

        {/* Category Navigation Pills */}
        <div className="flex flex-wrap justify-center gap-2 md:gap-4 mb-12">
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => {
                audioSynth.playClick();
                setActiveCategory(cat.id);
              }}
              className={`px-5 py-2.5 rounded-full text-sm font-semibold transition-all duration-300 relative overflow-hidden ${
                activeCategory === cat.id
                  ? "bg-navy text-white shadow-lg shadow-navy/20"
                  : "bg-white/60 hover:bg-white text-navy/70 hover:text-navy border border-navy/5"
              }`}
            >
              <span className="relative z-10">{cat.name}</span>
              {activeCategory === cat.id && (
                <motion.div
                  layoutId="activeCategoryBg"
                  className="absolute inset-0 bg-navy -z-0"
                  transition={{ type: "spring", stiffness: 300, damping: 30 }}
                />
              )}
            </button>
          ))}
        </div>

        {/* Full-Width Grid of Skills Selector List */}
        <div className="max-w-5xl mx-auto">
          <h3 className="font-sans text-xs font-bold text-navy/40 uppercase tracking-wider mb-6 flex items-center justify-center gap-2">
            <Target size={16} className="text-electric animate-pulse" /> Tap any Capability for Live Deep Breakdown
          </h3>
          
          <motion.div 
            variants={containerVariants}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-100px" }}
            onViewportEnter={() => playWhooshSound()}
            className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-2 lg:grid-cols-3 gap-6"
          >
            <AnimatePresence mode="popLayout">
              {filteredSkills.map((skill, i) => {
                const isSelected = selectedSkill.title === skill.title;
                return (
                  <motion.div
                    key={skill.title}
                    variants={cardVariants}
                    whileHover={{ scale: 1.03, y: -4 }}
                    whileTap={{ scale: 0.98 }}
                    onClick={() => {
                      setSelectedSkill(skill);
                    }}
                    className="p-6 rounded-2xl cursor-pointer transition-all duration-300 relative border overflow-hidden bg-white/65 hover:bg-white border-navy/5 shadow-sm hover:shadow-xl hover:border-electric/30 group"
                  >
                    <div className="flex justify-between items-start gap-4 mb-4">
                      <div className="flex items-start gap-2.5 flex-1 min-w-0">
                        <CheckCircle2
                          className="transition-colors shrink-0 mt-1 text-emerald-500Group hover:text-electric text-emerald-500"
                          size={18}
                        />
                        <span className="font-bold text-navy text-sm md:text-base leading-tight break-words flex-1 min-w-0 group-hover:text-electric transition-colors">
                          {skill.title}
                        </span>
                      </div>
                      <span className="font-mono text-xs font-black text-electric/90 bg-electric/5 px-2.5 py-1 rounded-md shrink-0">
                        <CountUp end={skill.level} suffix="%" />
                      </span>
                    </div>

                    {/* Proficiency animated progress bar */}
                    <div title={`${skill.level}%`} className="w-full bg-navy/5 h-2 rounded-full overflow-hidden mt-2 inline-block">
                      <motion.div
                        initial={{ width: 0 }}
                        animate={{ width: `${skill.level}%` }}
                        transition={{ duration: 1.2, ease: "easeOut" }}
                        style={{ backgroundColor: getDynamicColor(skill.level) }}
                        className="h-full rounded-full"
                      />
                    </div>
                    
                    <div className="mt-3 text-[11px] text-charcoal/50 font-medium flex items-center justify-between animate-none">
                      <span className="uppercase tracking-widest text-[9px] text-navy/40 font-mono">{skill.category}</span>
                      <span 
                        onClick={(e) => {
                          e.stopPropagation();
                          audioSynth.playOpenSwell();
                          setSelectedSkill(skill);
                          setIsModalOpen(true);
                        }}
                        className="text-electric group-hover:translate-x-1 transition-transform inline-flex items-center gap-0.5 cursor-pointer font-bold border border-electric/20 hover:border-electric/40 bg-electric/5 hover:bg-electric/15 px-2.5 py-1 rounded-lg transition-colors"
                      >
                        Explore ➜
                      </span>
                    </div>
                  </motion.div>
                );
              })}
            </AnimatePresence>
          </motion.div>
        </div>
      </div>

      {/* Modern Pop-Up Modal Dynamic Deep-Dive Performance Console */}
      <AnimatePresence>
        {isModalOpen && (
          <div className="fixed inset-0 z-[10000] flex items-center justify-center p-4">
            {/* Backdrop Blur Overlay with click handling */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => {
                audioSynth.playCloseSwell();
                setIsModalOpen(false);
              }}
              className="fixed inset-0 bg-navy/60 backdrop-blur-md cursor-pointer"
            />

            {/* Modal Card content Container */}
            <motion.div
              initial={{ opacity: 0, scale: 0.9, y: 30 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 30 }}
              transition={{ type: "spring", damping: 25, stiffness: 220 }}
              className="bg-white border border-navy/10 p-6 md:p-8 rounded-3xl shadow-3xl max-w-lg w-full relative z-10 flex flex-col overflow-hidden max-h-[92vh] overflow-y-auto"
              data-lenis-prevent
            >
              {/* Close Button Cross Icon ❌ */}
              <button
                onClick={() => {
                  audioSynth.playCloseSwell();
                  setIsModalOpen(false);
                }}
                className="absolute top-5 right-5 p-2 rounded-full text-charcoal hover:text-red-500 hover:bg-navy/5 bg-cream/80 transition-all duration-300 z-50 flex items-center justify-center hover:scale-110 active:scale-90"
                aria-label="Close modal"
              >
                <X size={20} className="stroke-[2.5px]" />
              </button>

              <div className="absolute top-0 right-0 p-4 opacity-10 shrink-0 pointer-events-none">
                <Cpu size={140} className="text-navy rotate-6" />
              </div>

              {/* Console Header */}
              <div className="mb-5 flex items-center justify-between mt-2">
                <span className="inline-flex items-center gap-1 bg-electric/5 text-electric px-3 py-1 rounded-full text-xs font-bold tracking-wide uppercase border border-electric/10">
                  <Award size={14} /> Capability Breakdown
                </span>
                <span className="text-xs font-mono font-bold text-navy/40 mr-10">ID: RUT-{selectedSkill.category.toUpperCase()}</span>
              </div>

              {/* Dynamic Radial circular Gauge */}
              <div className="flex flex-col items-center justify-center my-4 shrink-0">
                <div className="relative w-36 h-36 flex items-center justify-center">
                  {/* Gauge Tracker Circle */}
                  <svg className="w-full h-full transform -rotate-90" viewBox="0 0 144 144">
                    <circle
                      cx="72"
                      cy="72"
                      r={radius}
                      className="stroke-navy/5 fill-transparent"
                      strokeWidth="11"
                    />
                    {/* Animated Fill Dial */}
                    <motion.circle
                      cx="72"
                      cy="72"
                      r={radius}
                      className="stroke-electric fill-transparent"
                      strokeWidth="11"
                      strokeDasharray={circumference}
                      initial={{ strokeDashoffset: circumference }}
                      animate={{ strokeDashoffset }}
                      transition={{ duration: 1.2, ease: "easeOut" }}
                      strokeLinecap="round"
                    />
                  </svg>
                  {/* Score Label inside radial gauge */}
                  <div className="absolute inset-0 flex flex-col items-center justify-center">
                    <span className="text-3xl font-black font-mono text-navy tracking-tighter">
                      <CountUp end={selectedSkill.level} />
                    </span>
                    <span className="text-[10px] font-bold text-electric uppercase tracking-widest mt-0.5">Rating</span>
                  </div>
                </div>
              </div>

              {/* Skill Description */}
              <div className="flex-1 mt-2">
                <h4 className="text-xl md:text-2xl font-bold text-navy mb-3 font-serif leading-tight">
                  {selectedSkill.title}
                </h4>
                
                <p className="text-charcoal/80 text-sm md:text-base leading-relaxed mb-6">
                  {selectedSkill.desc}
                </p>

                {/* Sub Attributes / Proficiency indicators */}
                <div className="space-y-4 pt-4 border-t border-navy/5">
                  <h5 className="text-xs font-bold text-navy uppercase tracking-widest flex items-center gap-1.5 mb-2">
                    <TrendingUp size={14} className="text-electric animate-bounce" /> Breakdown Metric
                  </h5>
                  
                  <div className="grid gap-3.5">
                    {selectedSkill.subAttributes.map((attr, idx) => (
                      <div key={attr.name} className="flex flex-col gap-1.5">
                        <div className="flex justify-between items-center text-xs">
                          <span className="font-semibold text-charcoal/80">{attr.name}</span>
                          <span className="font-mono font-bold text-electric">
                            <CountUp end={attr.value} suffix="%" />
                          </span>
                        </div>
                        <div className="w-full bg-navy/5 h-2 rounded-full overflow-hidden">
                          <motion.div
                            initial={{ width: 0 }}
                            animate={{ width: `${attr.value}%` }}
                            transition={{ duration: 1.0, delay: idx * 0.08, ease: "easeOut" }}
                            className="bg-navy h-full rounded-full"
                          />
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
              
              {/* Decorative Console Footer */}
              <div className="mt-8 pt-4 border-t border-navy/5 flex items-center justify-between text-[11px] text-navy/40 font-mono shrink-0">
                <div className="flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                  <span>Telemetry Synced</span>
                </div>
                <span>99.8% PRECISION</span>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </section>
  );
}
