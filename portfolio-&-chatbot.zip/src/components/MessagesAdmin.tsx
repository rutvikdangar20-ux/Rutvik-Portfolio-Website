import React, { useEffect, useState } from 'react';
import { collection, onSnapshot, query, doc, deleteDoc, writeBatch, setDoc } from 'firebase/firestore';
import { db, useProfile, DEFAULT_PROFILE, handleFirestoreError, OperationType } from './firebase';
import { Download, Loader2, Lock, Trash2, Share2, AlertTriangle, Check, X, ShieldAlert, ArrowLeft, LogOut, Globe, Mail, RefreshCcw, Info, Image, FileText, Eye, Clock } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { useToast } from './ToastContext';

const isImageUrl = (url: string | null | undefined): boolean => {
  if (!url) return false;
  const cleanUrl = url.toLowerCase().split('?')[0];
  return cleanUrl.endsWith(".png") || cleanUrl.endsWith(".jpg") || cleanUrl.endsWith(".jpeg") || cleanUrl.endsWith(".gif") || cleanUrl.endsWith(".webp") || cleanUrl.endsWith(".svg");
};

const ensureHttps = (url: string | null | undefined): string => {
  if (!url) return "";
  if (url.startsWith("http://") && !url.includes("localhost") && !url.includes("127.0.0.1") && !url.includes("192.168.")) {
    return url.replace("http://", "https://");
  }
  return url;
};

const renderMessageWithLinks = (text: string) => {
  if (!text) return null;
  const urlRegex = /(https?:\/\/[^\s]+|www\.[^\s]+)/g;
  const parts = text.split(urlRegex);
  
  return parts.map((part, index) => {
    if (urlRegex.test(part)) {
      let href = part;
      if (!part.startsWith("http://") && !part.startsWith("https://")) {
        href = `https://${part}`;
      }
      href = ensureHttps(href);
      return (
        <a
          key={index}
          href={href}
          target="_blank"
          rel="noopener noreferrer"
          className="text-electric hover:underline font-bold break-all inline"
          onClick={(e) => e.stopPropagation()}
        >
          {part}
        </a>
      );
    }
    return part;
  });
};

export default function MessagesAdmin() {
  const { profile } = useProfile();
  const [activeTab, setActiveTab] = useState<'messages' | 'profile'>('messages');
  const [editName, setEditName] = useState('');
  const [editTitle, setEditTitle] = useState('');
  const [editBio, setEditBio] = useState('');
  const [editPhotoUrl, setEditPhotoUrl] = useState('');
  const [uploadingPhoto, setUploadingPhoto] = useState(false);
  const [savingProfile, setSavingProfile] = useState(false);

  useEffect(() => {
    if (profile) {
      setEditName(profile.name);
      setEditTitle(profile.title);
      setEditBio(profile.bio);
      setEditPhotoUrl(profile.photoUrl);
    }
  }, [profile]);

  const [messages, setMessages] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  
  const [lockoutTier, setLockoutTier] = useState<number>(() => {
    const saved = localStorage.getItem("admin_lockout_tier");
    return saved ? parseInt(saved, 10) : 1;
  });

  const [failedAttempts, setFailedAttempts] = useState<number>(() => {
    const saved = localStorage.getItem("admin_failed_attempts");
    return saved ? parseInt(saved, 10) : 0;
  });

  const [lockoutUntil, setLockoutUntil] = useState<number | null>(() => {
    const saved = localStorage.getItem("admin_lockout_until");
    return saved ? parseInt(saved, 10) : null;
  });

  const [timeLeft, setTimeLeft] = useState<number>(0);
  const [isShaking, setIsShaking] = useState(false);

  const getMaxAttemptsForTier = (tier: number) => {
    if (tier === 1) return 4;
    if (tier === 2) return 2;
    return 1;
  };

  const getLockoutDurationForTier = (tier: number) => {
    if (tier === 1) return 5; // 5 minutes
    if (tier === 2) return 15; // 15 minutes
    return 59; // 59 minutes
  };
  
  const [confirmingDeleteId, setConfirmingDeleteId] = useState<string | null>(null);
  const [showResetModal, setShowResetModal] = useState(false);
  const [sendingTestEmail, setSendingTestEmail] = useState(false);
  const { addToast } = useToast();

  const [emailLogs, setEmailLogs] = useState<any[]>([]);
  const [photoViews, setPhotoViews] = useState<any[]>([]);
  const [photoTotalCount, setPhotoTotalCount] = useState<number | null>(null);
  const [loadingLogs, setLoadingLogs] = useState(false);
  const [testingConnection, setTestingConnection] = useState(false);

  const seenLogIds = React.useRef<Set<string>>(new Set());
  const isFirstLogsFetch = React.useRef<boolean>(true);

  const fetchEmailLogs = async (silent = false) => {
    if (!silent) setLoadingLogs(true);
    try {
      const res = await fetch("/api/email-logs");
      if (res.ok) {
        const contentType = res.headers.get("content-type");
        if (contentType && contentType.includes("application/json")) {
          const data = await res.json();

          // Check for new failures if this is not the absolute first load
          if (!isFirstLogsFetch.current) {
            data.forEach((log: any) => {
              if (log.status === "failed" && !seenLogIds.current.has(log.id)) {
                addToast(`[SMTP Failure] "${log.subject}" failed to send! Error: ${log.error || "Unknown error"}`, "error");
              }
            });
          }

          // Track all IDs as seen
          data.forEach((log: any) => {
            seenLogIds.current.add(log.id);
          });
          isFirstLogsFetch.current = false;

          setEmailLogs(data);
        } else {
          console.warn("fetchEmailLogs: Server returned unexpected content-type:", contentType);
        }
      }
    } catch (err) {
      console.warn("Error fetching email logs silently handled:", err);
    } finally {
      if (!silent) setLoadingLogs(false);
    }
  };

  const handleTestSmtpConnection = async () => {
    setTestingConnection(true);
    try {
      const res = await fetch("/api/test-smtp");
      const contentType = res.headers.get("content-type");
      if (res.ok && contentType && contentType.includes("application/json")) {
        const data = await res.json();
        if (data.success) {
          addToast(data.message || "SMTP Connection test succeeded! Server is reachable.", "success");
        } else {
          addToast(data.error || "SMTP Connection test failed.", "error");
        }
      } else {
        const bodyText = await res.text();
        console.warn("handleTestSmtpConnection: unexpected response", bodyText);
        addToast("Unexpected response from server. Check SMTP settings.", "error");
      }
      fetchEmailLogs();
    } catch (err: any) {
      console.error(err);
      addToast("Network error trying to test SMTP Connection.", "error");
    } finally {
      setTestingConnection(false);
    }
  };

  const handleSendTestEmail = async () => {
    setSendingTestEmail(true);
    try {
      const res = await fetch("/api/test-email");
      const contentType = res.headers.get("content-type");
      if (res.ok && contentType && contentType.includes("application/json")) {
        const data = await res.json();
        if (data.success) {
          addToast(data.message || "Test email sent successfully!", "success");
        } else {
          addToast(data.error || "Failed to send test email.", "error");
        }
      } else {
        const bodyText = await res.text();
        console.warn("handleSendTestEmail: unexpected response", bodyText);
        addToast("Unexpected response from SMTP server. Check credentials.", "error");
      }
      fetchEmailLogs();
    } catch (err: any) {
      console.error(err);
      addToast("Network error trying to send test email.", "error");
    } finally {
      setSendingTestEmail(false);
    }
  };

  // Lockout live tick for Admin Messages
  useEffect(() => {
    if (!lockoutUntil) {
      setTimeLeft(0);
      return;
    }

    const checkLockout = () => {
      const now = Date.now();
      if (now >= lockoutUntil) {
        setLockoutUntil(null);
        setFailedAttempts(0);
        localStorage.removeItem("admin_lockout_until");
        localStorage.setItem("admin_failed_attempts", "0");
        setTimeLeft(0);
        setError('');
      } else {
        setTimeLeft(Math.ceil((lockoutUntil - now) / 1000));
      }
    };

    checkLockout();
    const interval = setInterval(checkLockout, 1000);
    return () => clearInterval(interval);
  }, [lockoutUntil]);

  // Inactivity auto-logout timer (10 minutes)
  useEffect(() => {
    if (!isAuthenticated) return;

    let timeoutId: NodeJS.Timeout;

    const handleInactivityLogout = () => {
      setIsAuthenticated(false);
      addToast('Logged out due to 10 minutes of inactivity.', 'info');
      
      // Redirect back to portfolio
      window.history.pushState({}, "", "/");
      window.dispatchEvent(new Event("popstate"));
    };

    const resetInactivityTimer = () => {
      if (timeoutId) clearTimeout(timeoutId);
      timeoutId = setTimeout(handleInactivityLogout, 10 * 60 * 1000); // 10 minutes
    };

    // Set initial timer
    resetInactivityTimer();

    // Listen to user interaction events to keep session alive
    const events = ['mousemove', 'keydown', 'click', 'scroll', 'touchstart'];
    events.forEach(event => {
      window.addEventListener(event, resetInactivityTimer);
    });

    return () => {
      if (timeoutId) clearTimeout(timeoutId);
      events.forEach(event => {
        window.removeEventListener(event, resetInactivityTimer);
      });
    };
  }, [isAuthenticated, addToast]);

  const formatCountdown = (totalSeconds: number) => {
    const minutes = Math.floor(totalSeconds / 60);
    const seconds = totalSeconds % 60;
    return `${minutes.toString().padStart(2, "0")}:${seconds.toString().padStart(2, "0")}`;
  };

  useEffect(() => {
    if (!isAuthenticated) return;

    const fetchMessages = () => {
      try {
        const q = query(collection(db, 'messages'));
        const unsubscribe = onSnapshot(q, (querySnapshot) => {
          const data: any[] = [];
          querySnapshot.forEach((doc) => {
            data.push({ id: doc.id, ...doc.data() });
          });
          // Sort descending by createdAt in JS
          data.sort((a, b) => {
            const tA = a.createdAt?.toMillis ? a.createdAt.toMillis() : Date.now();
            const tB = b.createdAt?.toMillis ? b.createdAt.toMillis() : Date.now();
            return tB - tA;
          });
          setMessages(data);
          setLoading(false);
        }, (error) => {
          console.error('Error fetching messages in realtime:', error);
          setLoading(false);
        });
        return unsubscribe;
      } catch (error) {
        console.error('Error setting up onSnapshot:', error);
        setLoading(false);
      }
    };

    const fetchPhotoViews = () => {
      try {
        const q = query(collection(db, 'photo_views'));
        const unsubscribe = onSnapshot(q, (querySnapshot) => {
          const data: any[] = [];
          querySnapshot.forEach((doc) => {
            data.push({ id: doc.id, ...doc.data() });
          });
          // Sort descending by createdAt
          data.sort((a, b) => {
            const tA = a.createdAt?.toMillis ? a.createdAt.toMillis() : Date.now();
            const tB = b.createdAt?.toMillis ? b.createdAt.toMillis() : Date.now();
            return tB - tA;
          });
          setPhotoViews(data);
        }, (error) => {
          console.error('Error fetching photo views in realtime:', error);
        });
        return unsubscribe;
      } catch (error) {
        console.error('Error setting up photo_views subscription:', error);
      }
    };

    const fetchPhotoTotalCount = () => {
      try {
        const docRef = doc(db, 'stats', 'photo_view_counter');
        const unsubscribe = onSnapshot(docRef, (docSnap) => {
          if (docSnap.exists()) {
            setPhotoTotalCount(docSnap.data().count || 0);
          } else {
            setPhotoTotalCount(0);
          }
        }, (error) => {
          console.error('Error fetching photo view count in realtime:', error);
        });
        return unsubscribe;
      } catch (error) {
        console.error('Error setting up photo_view_counter subscription:', error);
      }
    };

    const unsubscribe = fetchMessages();
    const unsubscribePhoto = fetchPhotoViews();
    const unsubscribePhotoTotal = fetchPhotoTotalCount();
    fetchEmailLogs();

    // Poll for new email dispatch logs every 10 seconds to discover failures and trigger alerts
    const pollInterval = setInterval(() => {
      fetchEmailLogs(true);
    }, 10000);

    return () => {
      if (unsubscribe) {
        unsubscribe();
      }
      if (unsubscribePhoto) {
        unsubscribePhoto();
      }
      if (unsubscribePhotoTotal) {
        unsubscribePhotoTotal();
      }
      clearInterval(pollInterval);
    };
  }, [isAuthenticated]);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (lockoutUntil && Date.now() < lockoutUntil) {
      return;
    }

    const enteredPassword = password;
    setPassword(''); // Clear the password input instantly as requested by user

    if (enteredPassword === 'dangarrutvik@100#') {
      setIsAuthenticated(true);
      setError('');
      setFailedAttempts(0);
      setLockoutTier(1);
      localStorage.setItem("admin_failed_attempts", "0");
      localStorage.setItem("admin_lockout_tier", "1");
      localStorage.removeItem("admin_lockout_until");
      addToast('Authenticated successfully!', 'success');
    } else {
      // Trigger input field shaking state instantly
      setIsShaking(true);
      setTimeout(() => setIsShaking(false), 500);

      const maxAttempts = getMaxAttemptsForTier(lockoutTier);
      const newAttempts = failedAttempts + 1;

      if (newAttempts >= maxAttempts) {
        const durationMins = getLockoutDurationForTier(lockoutTier);
        const cooldownMs = durationMins * 60 * 1000;
        const until = Date.now() + cooldownMs;
        
        setLockoutUntil(until);
        localStorage.setItem("admin_lockout_until", until.toString());

        // Advance lockout tier for next period
        const nextTier = Math.min(3, lockoutTier + 1);
        setLockoutTier(nextTier);
        localStorage.setItem("admin_lockout_tier", nextTier.toString());

        // Reset failed attempts for the next tier starting fresh
        setFailedAttempts(0);
        localStorage.setItem("admin_failed_attempts", "0");

        setError(`Maximum wrong attempts reached. System locked for ${durationMins} minutes!`);
        addToast(`System Locked for ${durationMins} minutes due to multiple failed logins!`, 'error');
      } else {
        setFailedAttempts(newAttempts);
        localStorage.setItem("admin_failed_attempts", newAttempts.toString());
        setError(`Incorrect password. Attempt ${newAttempts} of ${maxAttempts} failed.`);
      }
    }
  };

  const handleDeleteMessage = async (id: string) => {
    try {
      await deleteDoc(doc(db, 'messages', id));
      addToast('Message deleted successfully', 'success');
      setConfirmingDeleteId(null);
    } catch (error) {
      console.error('Error deleting document: ', error);
      addToast('Failed to delete message', 'error');
    }
  };

  const handleResetAllMessages = async () => {
    try {
      const batch = writeBatch(db);
      messages.forEach((msg) => {
        batch.delete(doc(db, 'messages', msg.id));
      });
      await batch.commit();
      addToast('All messages deleted successfully', 'success');
    } catch (error) {
      console.error('Error resetting messages: ', error);
      addToast('Failed to delete all messages', 'error');
    }
  };

  const handlePhotoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;
    const file = files[0];
    
    if (!file.type.startsWith("image/")) {
      addToast("Please upload an image file (PNG, JPG, etc.)", "error");
      return;
    }
    
    setUploadingPhoto(true);
    const formData = new FormData();
    formData.append("file", file);
    
    try {
      const res = await fetch("/api/analyze-file", {
        method: "POST",
        body: formData,
      });
      if (res.ok) {
        const data = await res.json();
        if (data.fileUrl) {
          // Store relative path if available, else complete url
          setEditPhotoUrl(data.filePath || data.fileUrl);
          addToast("Photo uploaded successfully! Click save to update profile.", "success");
        } else {
          addToast("Unexpected upload response structure.", "error");
        }
      } else {
        addToast("Photo upload failed on server.", "error");
      }
    } catch (err: any) {
      console.error("Error uploading photo:", err);
      addToast("Photo upload error: " + (err.message || String(err)), "error");
    } finally {
      setUploadingPhoto(false);
    }
  };

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editName.trim()) {
      addToast("Name cannot be empty", "error");
      return;
    }
    setSavingProfile(true);
    const path = "settings/profile";
    try {
      const docRef = doc(db, "settings", "profile");
      await setDoc(docRef, {
        name: editName.trim(),
        title: editTitle.trim(),
        bio: editBio.trim(),
        photoUrl: editPhotoUrl,
      }, { merge: true });
      addToast("Executive profile updated successfully across the entire portfolio website! 🎉", "success");
    } catch (err: any) {
      console.error("Error saving profile settings:", err);
      addToast("Failed to save profile: " + (err.message || String(err)), "error");
      handleFirestoreError(err, OperationType.WRITE, path);
    } finally {
      setSavingProfile(false);
    }
  };

  const handleShare = async (msg: any) => {
    const dateStr = msg.createdAt?.toDate 
      ? msg.createdAt.toDate().toLocaleString() 
      : (msg.createdAt instanceof Date ? msg.createdAt.toLocaleString() : 'Just now');
      
    const textToShare = `--- Contact Message ---\n👤 From: ${msg.name}\n📧 Email: ${msg.email}\n📅 Date: ${dateStr}\n\n💬 Message:\n${msg.message}`;
    
    if (navigator.share) {
      try {
        await navigator.share({
          title: `Message from ${msg.name}`,
          text: textToShare,
        });
        addToast('Shared successfully!', 'success');
      } catch (err) {
        // If user cancel sharing, don't show error toast
        console.log('Share canceled or failed:', err);
      }
    } else {
      try {
        await navigator.clipboard.writeText(textToShare);
        addToast('Message details copied to clipboard!', 'success');
      } catch (err) {
        addToast('Failed to copy to clipboard', 'error');
      }
    }
  };

  return (
    <AnimatePresence mode="wait">
      {!isAuthenticated ? (
        <motion.div
          key="admin-login-view"
          initial={{ opacity: 0, scale: 0.98 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.98 }}
          transition={{ duration: 0.45, ease: [0.16, 1, 0.3, 1] }}
          className="min-h-screen bg-[#0a1628] text-white flex items-center justify-center p-6 relative overflow-hidden w-full"
        >
          {/* Futuristic ambient backing lights */}
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-blue-900/15 via-navy to-[#0a1628] opacity-90 pointer-events-none" />
          <div className="absolute -top-[10%] -left-[10%] w-[50%] h-[50%] rounded-full bg-electric/5 blur-[120px] pointer-events-none" />
          <div className="absolute top-[60%] -right-[10%] w-[40%] h-[40%] rounded-full bg-purple-500/5 blur-[100px] pointer-events-none" />

          <motion.div 
            initial={{ opacity: 0, scale: 0.9, y: 30 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          transition={{ type: "spring", damping: 26, stiffness: 170, mass: 0.8 }}
          className="bg-white/[0.03] border border-white/10 rounded-3xl p-8 max-w-md w-full relative overflow-hidden backdrop-blur-2xl shadow-[0_25px_60px_rgba(0,0,0,0.5)] z-10"
        >
          <div className="absolute inset-x-0 top-0 h-1 bg-gradient-to-r from-red-500 via-electric to-purple-600 opacity-80" />
          <div className="flex justify-center mb-6 pt-2">
            <motion.div 
              initial={{ scale: 0.8, rotate: -15 }}
              animate={{ scale: 1, rotate: 0 }}
              transition={{ delay: 0.15, type: "spring", stiffness: 200, damping: 15 }}
              className="w-16 h-16 bg-electric/20 text-electric rounded-2xl flex items-center justify-center shadow-[0_0_25px_rgba(35,154,59,0.3)] border border-electric/30"
            >
              <Lock size={28} />
            </motion.div>
          </div>
          <h1 className="text-2xl font-serif font-bold text-center mb-2 text-white">Admin Access</h1>
          <p className="text-white/50 text-xs text-center mb-8">Access private contact queries and dashboard updates</p>
          <motion.form 
            onSubmit={handleLogin} 
            className="space-y-4"
            animate={isShaking ? { x: [-10, 10, -8, 8, -5, 5, -2.5, 2.5, 0] } : {}}
            transition={{ duration: 0.4, ease: "easeInOut" }}
          >
            <div>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder={timeLeft > 0 ? "Blocked - Try again later" : "Enter admin password"}
                disabled={timeLeft > 0}
                className="w-full bg-navy border border-white/10 rounded-xl px-4 py-3.5 text-white placeholder-white/30 focus:outline-none focus:border-electric focus:ring-2 focus:ring-electric/20 transition-all shadow-inner font-sans tracking-wide text-sm disabled:opacity-50 disabled:cursor-not-allowed"
                autoFocus={timeLeft === 0}
              />
            </div>
            
            {timeLeft === 0 && (
              <div className="flex flex-col items-center gap-2 py-1.5 select-none bg-white/5 border border-white/5 rounded-xl">
                <div className="flex gap-2.5 justify-center mt-1">
                  {Array.from({ length: getMaxAttemptsForTier(lockoutTier) }).map((_, idx) => (
                    <div
                      key={idx}
                      className={`w-2.5 h-2.5 rounded-full border transition-all duration-300 ${
                        idx < failedAttempts
                          ? "bg-red-500 border-red-500 shadow-[0_0_10px_rgba(239,68,68,0.7)] scale-110"
                          : "bg-white/10 border-white/20"
                      }`}
                    />
                  ))}
                </div>
                <p className="text-[10px] uppercase font-bold tracking-widest text-white/40 mb-0.5">
                  Tier {lockoutTier} Cooldown • <span className="text-red-400 font-bold">{getMaxAttemptsForTier(lockoutTier) - failedAttempts} left</span>
                </p>
              </div>
            )}
            
            {timeLeft > 0 && (
              <div className="text-xs text-red-200 font-bold bg-red-950/40 p-3 rounded-xl border border-red-800/30 text-center space-y-1.5 my-2">
                <p className="uppercase tracking-widest text-[9px] text-red-400/60 font-semibold">Maximum attempts reached</p>
                <p className="text-xl font-mono tracking-wider text-red-300">
                  {formatCountdown(timeLeft)}
                </p>
                <p className="text-[10px] text-red-400/50 font-normal">Please wait until lockout period ends</p>
              </div>
            )}

            {error && timeLeft === 0 && <p className="text-red-400 text-sm text-center font-medium animate-pulse">{error}</p>}
            
            <button
              type="submit"
              disabled={timeLeft > 0}
              className="w-full bg-electric text-navy font-bold py-3.5 px-6 rounded-xl hover:bg-electric hover:shadow-electric/30 transition-all hover:scale-[1.02] active:scale-95 shadow-lg shadow-electric/20 text-sm cursor-pointer disabled:bg-white/10 disabled:text-white/30 disabled:scale-100 disabled:cursor-not-allowed"
            >
              Access Messages
            </button>
          </motion.form>
          <div className="mt-6 pt-6 border-t border-white/5 text-center">
            <button
              type="button"
              onClick={() => {
                window.history.pushState({}, "", "/");
                window.dispatchEvent(new Event("popstate"));
              }}
              className="text-white/40 hover:text-white/80 transition-colors text-xs inline-flex items-center gap-1.5 cursor-pointer font-medium"
            >
              <ArrowLeft size={14} /> Back to Portfolio Website
            </button>
          </div>
        </motion.div>
      </motion.div>
    ) : (
      <motion.div
        key="admin-dashboard-view"
        initial={{ opacity: 0, scale: 0.98 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.98 }}
        transition={{ duration: 0.45, ease: [0.16, 1, 0.3, 1] }}
        className="min-h-screen bg-navy text-white px-4 py-8 sm:p-6 md:p-12 relative overflow-hidden w-full max-w-full"
      >
      {/* Background visual glows */}
      <div className="absolute top-[-20%] right-[-10%] w-[500px] h-[500px] bg-electric/5 rounded-full blur-[150px] pointer-events-none" />
      <div className="absolute bottom-[-10%] left-[-10%] w-[400px] h-[400px] bg-purple-500/5 rounded-full blur-[120px] pointer-events-none" />

      <div className="max-w-6xl mx-auto relative z-10 w-full overflow-hidden">
        {/* Admin Navigation Bar */}
        <div className="flex justify-between items-center pb-6 mb-8 border-b border-white/10 flex-wrap gap-4">
          <button
            type="button"
            onClick={() => {
              window.history.pushState({}, "", "/");
              window.dispatchEvent(new Event("popstate"));
            }}
            className="inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-white/60 hover:text-white bg-white/5 hover:bg-white/10 px-4 py-2.5 rounded-xl border border-white/5 transition-all active:scale-95 cursor-pointer"
          >
            <ArrowLeft size={14} />
            Back to Website
          </button>
          
          <button
            type="button"
            onClick={() => {
              setIsAuthenticated(false);
              addToast("Logged out successfully", "success");
            }}
            className="inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-red-300 hover:text-red-200 bg-red-500/10 hover:bg-red-500/20 px-4 py-2.5 rounded-xl border border-red-500/10 transition-all active:scale-95 cursor-pointer"
          >
            <LogOut size={14} />
            Log Out
          </button>
        </div>

        {/* Tab Selector Buttons */}
        <div className="flex gap-4 border-b border-white/10 pb-4 mb-8">
          <button
            onClick={() => setActiveTab('messages')}
            className={`px-5 py-2.5 rounded-xl font-bold text-xs sm:text-sm tracking-wide transition-all cursor-pointer flex items-center gap-2 ${
              activeTab === 'messages'
                ? "bg-electric text-navy shadow-md shadow-electric/25 font-bold scale-[1.02]"
                : "bg-white/5 text-white/60 hover:text-white border border-white/5 hover:bg-white/10"
            }`}
          >
            <Mail size={16} />
            Inbox & Telemetry ({messages.length})
          </button>
          <button
            onClick={() => setActiveTab('profile')}
            className={`px-5 py-2.5 rounded-xl font-bold text-xs sm:text-sm tracking-wide transition-all cursor-pointer flex items-center gap-2 ${
              activeTab === 'profile'
                ? "bg-electric text-navy shadow-md shadow-electric/25 font-bold scale-[1.02]"
                : "bg-white/5 text-white/60 hover:text-white border border-white/5 hover:bg-white/10"
            }`}
          >
            <Image size={16} />
            Edit Profile Setting
          </button>
        </div>

        {activeTab === 'messages' ? (
          <>
            <div className="flex justify-between items-center mb-10 flex-wrap gap-4 w-full">
              <h1 className="text-2xl sm:text-3xl font-serif font-bold tracking-tight text-white flex items-center gap-2 sm:gap-3 flex-wrap">
                Contact Messages
                <span className="text-xs font-mono px-2.5 py-1 rounded-full bg-white/10 text-white/75 font-normal border border-white/5 shrink-0">
                  {messages.length} total
                </span>
              </h1>
          <div className="flex flex-wrap gap-2.5 sm:gap-3 w-full sm:w-auto">
            <button
              onClick={handleTestSmtpConnection}
              disabled={testingConnection}
              className="flex-1 sm:flex-initial inline-flex items-center justify-center gap-2 px-3 sm:px-4.5 py-2.5 bg-white/5 hover:bg-white/10 text-white rounded-xl border border-white/10 transition-all shadow-md text-xs sm:text-sm font-semibold active:scale-95 disabled:opacity-50 cursor-pointer"
            >
              {testingConnection ? (
                <Loader2 size={15} className="animate-spin text-electric" />
              ) : (
                <Mail size={15} className="text-electric" />
              )}
              SMTP Test
            </button>
            <button
              onClick={handleSendTestEmail}
              disabled={sendingTestEmail}
              className="flex-1 sm:flex-initial inline-flex items-center justify-center gap-2 px-3 sm:px-4.5 py-2.5 bg-gradient-to-r from-sky-600 to-sky-500 text-white hover:brightness-110 rounded-xl transition-all shadow-md text-xs sm:text-sm font-bold active:scale-95 disabled:opacity-50 cursor-pointer"
            >
              {sendingTestEmail ? (
                <Loader2 size={15} className="animate-spin" />
              ) : (
                <Globe size={15} />
              )}
              Test Email
            </button>
            {messages.length > 0 && (
              <button
                onClick={() => setShowResetModal(true)}
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-4 py-2.5 bg-red-600/95 hover:bg-red-700 text-white rounded-xl transition-all shadow-md hover:shadow-red-600/20 text-xs sm:text-sm font-semibold active:scale-101 border border-red-500/20 cursor-pointer"
              >
                <Trash2 size={15} />
                Reset All Messages
              </button>
            )}
          </div>
        </div>
        
        {loading ? (
          <div className="flex flex-col justify-center items-center h-64 gap-3">
            <Loader2 className="animate-spin text-electric" size={48} />
            <p className="text-white/40 text-sm font-mono">Loading dynamic reports...</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 items-start">
            {/* Left Column: Contact Messages */}
            <div className="lg:col-span-2 space-y-6">
              {messages.length === 0 ? (
                <div className="bg-white/5 border border-white/5 rounded-3xl p-16 text-center text-white/50 backdrop-blur-sm shadow-xl">
                  <div className="w-16 h-16 bg-white/5 rounded-2xl flex items-center justify-center mx-auto mb-4">
                    <ShieldAlert size={32} className="text-white/30" />
                  </div>
                  <p className="text-base font-serif font-semibold text-white/80">No messages found</p>
                  <p className="text-xs text-white/40 mt-1">When users submit the contact form, their queries will appear here in real-time.</p>
                </div>
              ) : (
                <div className="grid gap-6">
                  <AnimatePresence>
                    {messages.map((msg, index) => (
                      <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, scale: 0.95 }}
                        transition={{ duration: 0.4, delay: index * 0.05 }}
                        key={msg.id}
                        className="bg-white/[0.04] hover:bg-white/[0.06] border border-white/10 rounded-2xl p-4 sm:p-6 transition-all duration-300 relative shadow-lg group hover:border-white/20 w-full overflow-hidden"
                      >
                        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-4 gap-4 w-full">
                          <div className="min-w-0 max-w-full">
                            <h3 className="font-bold text-lg sm:text-xl font-serif text-white truncate break-words">{msg.name}</h3>
                            <p className="text-white/60 text-xs sm:text-sm mt-1 break-all">
                              <a href={`mailto:${msg.email}`} className="text-electric hover:underline font-mono break-all inline-block max-w-full">
                                {msg.email}
                              </a>
                            </p>
                          </div>
                          <div className="text-left sm:text-right text-xs text-white/40 font-mono bg-white/5 px-2.5 py-1.5 rounded-lg border border-white/5 shadow-inner shrink-0 max-w-full truncate">
                            {msg.createdAt?.toDate ? msg.createdAt.toDate().toLocaleString() : 
                             (msg.createdAt instanceof Date ? msg.createdAt.toLocaleString() : 'Just now')}
                          </div>
                        </div>
                        
                        <div className="bg-navy/70 rounded-xl p-3 sm:p-4 mb-4 whitespace-pre-wrap font-mono text-xs sm:text-sm leading-relaxed border border-white/5 text-slate-200 select-text break-words break-all overflow-hidden max-w-full">
                           {renderMessageWithLinks(msg.message)}
                           
                           {msg.attachmentUrl && (
                             <div className="mt-4 w-full max-w-full rounded-2xl overflow-hidden border border-white/10 bg-black/30 shadow-inner p-1 sm:p-2" onClick={(e) => e.stopPropagation()}>
                               {isImageUrl(msg.attachmentUrl) ? (
                                 <div className="group relative rounded-xl overflow-hidden max-h-60 bg-black/40 flex items-center justify-center border border-white/5">
                                   <img 
                                     src={ensureHttps(msg.attachmentUrl)} 
                                     alt="Attached preview" 
                                     referrerPolicy="no-referrer"
                                     className="max-h-60 max-w-full object-contain rounded-xl transition-all duration-300 group-hover:scale-[1.02]"
                                   />
                                   <div 
                                     onClick={() => window.open(ensureHttps(msg.attachmentUrl), "_blank")}
                                     className="absolute inset-0 bg-navy/60 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-all duration-250 cursor-pointer"
                                   >
                                     <span className="bg-white/10 backdrop-blur-md text-white font-sans text-xs px-3 sm:px-3.5 py-1.5 sm:py-2 rounded-xl border border-white/20 font-semibold shadow-md flex items-center gap-2">
                                       <Image size={14} className="text-electric" />
                                       Tap to Open Full Photo
                                     </span>
                                   </div>
                                 </div>
                               ) : (
                                 <div className="p-3 sm:p-4 bg-white/[0.02] hover:bg-white/[0.05] border border-white/5 rounded-xl flex items-center justify-between gap-3 sm:gap-4 transition-colors w-full overflow-hidden">
                                   <div className="flex items-center gap-2.5 sm:gap-3 min-w-0 flex-1">
                                     <div className="w-9 h-9 sm:w-10 sm:h-10 bg-white/5 hover:bg-white/10 text-electric rounded-xl flex items-center justify-center border border-white/10 transition-colors shrink-0">
                                       <FileText size={18} />
                                     </div>
                                     <div className="min-w-0 flex-1">
                                       <p className="text-xs sm:text-sm font-semibold truncate text-white/90 break-all">{msg.attachmentName || "Attached Document"}</p>
                                       <p className="text-[10px] sm:text-xs text-white/40 font-mono mt-0.5 truncate">Secure attachment storage</p>
                                     </div>
                                   </div>
                                   <a 
                                     href={ensureHttps(msg.attachmentUrl)}
                                     target="_blank"
                                     rel="noopener noreferrer"
                                     className="p-2 bg-electric/10 hover:bg-electric/25 border border-electric/10 text-electric rounded-lg transition-all shrink-0 ml-1.5"
                                     title="Download file"
                                   >
                                     <Download size={14} />
                                   </a>
                                 </div>
                               )}
                             </div>
                           )}
                         </div>

                        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4 pt-4 border-t border-white/5 w-full">
                          <div className="flex flex-wrap gap-2 w-full sm:w-auto">
                            {msg.attachmentUrl && (
                              <a
                                href={ensureHttps(msg.attachmentUrl)}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="inline-flex items-center justify-center gap-2 px-3 sm:px-4 py-2 bg-electric/20 text-electric rounded-xl hover:bg-electric/30 transition-colors text-xs sm:text-sm font-medium border border-electric/10 w-full sm:w-auto"
                              >
                                <Download size={14} />
                                View File
                              </a>
                            )}
                            
                            {!msg.attachmentUrl && msg.attachmentName && (
                              <div className="inline-flex items-center justify-center gap-2 px-3 sm:px-4 py-2 bg-white/5 text-white/70 rounded-xl text-xs sm:text-sm font-medium border border-white/5 w-full sm:w-auto select-none">
                                <Download size={14} />
                                <span className="truncate max-w-xs">{msg.attachmentName}</span>
                              </div>
                            )}
                          </div>

                          {confirmingDeleteId === msg.id ? (
                            <div className="flex items-center justify-between sm:justify-start gap-3 bg-red-500/10 border border-red-500/20 rounded-xl px-3 sm:px-4 py-2 text-red-200 w-full sm:w-auto select-none font-sans">
                              <div className="flex items-center gap-1.5 shrink-0">
                                <AlertTriangle size={15} className="text-red-400 animate-pulse" />
                                <span className="text-xs font-semibold text-red-300">Delete?</span>
                              </div>
                              <div className="flex gap-2">
                                <button 
                                  onClick={() => handleDeleteMessage(msg.id)} 
                                  className="bg-red-600 hover:bg-red-700 text-white text-[11px] sm:text-xs px-2.5 py-1.5 rounded-lg transition-all font-bold active:scale-90 shadow-md cursor-pointer shrink-0"
                                >
                                  Confirm
                                </button>
                                  <button 
                                  onClick={() => setConfirmingDeleteId(null)} 
                                  className="bg-white/10 hover:bg-white/20 text-white/80 text-[11px] sm:text-xs px-2.5 py-1.5 rounded-lg transition-all font-bold cursor-pointer shrink-0"
                                >
                                  Cancel
                                </button>
                              </div>
                            </div>
                          ) : (
                            <div className="flex gap-2.5 w-full sm:w-auto justify-end">
                              <button
                                onClick={() => handleShare(msg)}
                                className="flex-1 sm:flex-initial inline-flex items-center justify-center gap-2 px-3 py-2 bg-white/5 hover:bg-white/10 text-white/85 hover:text-white rounded-lg transition-all text-xs sm:text-sm font-medium border border-white/10 active:scale-95 cursor-pointer"
                                title="Share / Copy message details"
                              >
                                <Share2 size={13} />
                                Share
                              </button>
                              <button
                                onClick={() => setConfirmingDeleteId(msg.id)}
                                className="flex-1 sm:flex-initial inline-flex items-center justify-center gap-2 px-3 py-2 bg-red-500/10 hover:bg-red-500/20 text-red-300 hover:text-red-200 rounded-lg transition-all text-xs sm:text-sm font-medium border border-red-500/20 active:scale-95 cursor-pointer"
                                title="Delete message"
                              >
                                <Trash2 size={13} />
                                Delete
                              </button>
                            </div>
                          )}
                        </div>
                      </motion.div>
                    ))}
                  </AnimatePresence>
                </div>
              )}
            </div>

            {/* Right Column: SMTP Telemetry & Dispatch status logs */}
            <div className="space-y-6">
              <div className="bg-white/[0.04] border border-white/10 rounded-2xl p-6 shadow-xl relative overflow-hidden">
                <div className="absolute top-0 right-0 w-32 h-32 bg-electric/5 rounded-full blur-2xl pointer-events-none" />
                
                <div className="flex justify-between items-center mb-4 pb-3 border-b border-white/5">
                  <h2 className="font-serif font-bold text-lg text-white flex items-center gap-2">
                    <Mail size={18} className="text-electric" />
                    SMTP Dispatch Logs
                  </h2>
                  <button
                    onClick={() => fetchEmailLogs(false)}
                    disabled={loadingLogs}
                    className="p-1.5 px-2.5 text-xs bg-white/5 hover:bg-white/10 rounded-lg border border-white/10 flex items-center gap-1.5 transition-all disabled:opacity-50 cursor-pointer text-white/80"
                    title="Refresh telemetry logs"
                  >
                    <RefreshCcw size={12} className={loadingLogs ? "animate-spin" : ""} />
                    Refresh
                  </button>
                </div>

                <p className="text-xs text-white/50 mb-5 font-sans leading-relaxed">
                  Shows live telemetry of automated dispatch notification attempts triggered by portfolio contact forms and newsletter updates. Use this panel to diagnose mail flow errors.
                </p>

                {loadingLogs && emailLogs.length === 0 ? (
                  <div className="py-12 text-center text-white/30 text-xs font-mono animate-pulse">
                    <Loader2 size={18} className="animate-spin text-electric mx-auto mb-2" />
                    Connecting to telemetry...
                  </div>
                ) : emailLogs.length === 0 ? (
                  <div className="py-12 text-center text-white/30 text-xs font-mono border border-dashed border-white/15 rounded-xl bg-navy/30">
                    <Info size={16} className="mx-auto mb-2 text-white/20" />
                    No dispatch events yet
                  </div>
                ) : (
                          <div className="space-y-3 max-h-[480px] overflow-y-auto pr-1 w-full overflow-hidden">
                            {emailLogs.map((log) => {
                              const dateStr = new Date(log.timestamp).toLocaleTimeString();
                              return (
                                <div
                                  key={log.id}
                                  className="p-3 bg-navy/50 hover:bg-navy/30 rounded-xl border border-white/5 text-[11px] leading-tight flex flex-col gap-1.5 transition-all w-full overflow-hidden break-all"
                                >
                          <div className="flex items-center justify-between">
                            <span className="font-mono text-white/40">{dateStr}</span>
                            <span
                              className={`px-1.5 py-0.5 rounded text-[8px] font-extrabold uppercase tracking-widest ${
                                log.status === "success"
                                  ? "bg-emerald-500/10 text-emerald-400 border border-emerald-500/15"
                                  : log.status === "sandbox"
                                  ? "bg-sky-500/10 text-sky-400 border border-sky-500/15"
                                  : "bg-red-500/15 text-red-400 border border-red-500/15"
                              }`}
                            >
                              {log.status}
                            </span>
                          </div>
                          
                          <div className="font-serif font-bold text-white/95 truncate">
                            {log.subject}
                          </div>

                          <div className="font-mono text-white/50 text-[10px]">
                            Recipient: {log.to}
                          </div>

                          {log.info && (
                            <div className="text-white/40 bg-white/[0.03] p-1.5 rounded font-mono text-[9px] break-all leading-normal border border-white/[0.01]">
                              {log.info}
                            </div>
                          )}

                          {log.error && (
                            <div className="text-red-400 bg-red-950/20 p-1.5 rounded border border-red-900/25 font-mono text-[9px] break-all leading-normal">
                              <span className="font-bold text-red-300">Failure Msg:</span> {log.error}
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>

              {/* Photo View Telemetry Card */}
              <div className="bg-white/[0.04] border border-white/10 rounded-2xl p-6 shadow-xl relative overflow-hidden">
                <div className="absolute top-0 right-0 w-32 h-32 bg-purple-500/5 rounded-full blur-2xl pointer-events-none" />
                
                <div className="flex justify-between items-center mb-4 pb-3 border-b border-white/5">
                  <h2 className="font-serif font-bold text-lg text-white flex items-center gap-2">
                    <Eye size={18} className="text-purple-400" />
                    Photo Tracker Telemetry
                  </h2>
                  
                  {photoViews.length > 0 && (
                    <button
                      onClick={async () => {
                        if (confirm(`Do you want to clear all ${photoViews.length} photo view logs and reset the total tracking counter?`)) {
                          try {
                            const batch = writeBatch(db);
                            photoViews.forEach((v) => {
                              batch.delete(doc(db, 'photo_views', v.id));
                            });
                            batch.set(doc(db, 'stats', 'photo_view_counter'), { count: 0 }, { merge: true });
                            await batch.commit();
                            addToast("Cleared all photo view tracking logs and reset counter count successfully!", "success");
                          } catch (err) {
                            addToast("Failed to clear photo tracking logs.", "error");
                          }
                        }
                      }}
                      className="p-1 px-2 text-[10px] bg-red-500/10 hover:bg-red-500/25 text-red-300 rounded border border-red-500/20 active:scale-95 transition-all flex items-center gap-1 cursor-pointer"
                      title="Clear photo logs"
                    >
                      <Trash2 size={10} />
                      Purge Logs
                    </button>
                  )}
                </div>

                <div className="bg-[#581c87]/15 rounded-xl p-3 border border-purple-500/10 mb-5 text-xs text-purple-200">
                  <div className="flex justify-between font-mono font-bold">
                    <span>Total Hits logged:</span>
                    <span className="text-purple-300 text-sm font-sans font-black">
                      {photoTotalCount !== null ? photoTotalCount : photoViews.length} views
                    </span>
                  </div>
                  {photoViews.length > 0 && (
                    <div className="mt-1 flex justify-between font-mono text-[10px] text-purple-300/85">
                      <span>Max single duration:</span>
                      <span className="font-black text-white">
                        {Math.max(...photoViews.map(v => v.duration || 0)).toFixed(1)} seconds
                      </span>
                    </div>
                  )}
                </div>

                {photoViews.length === 0 ? (
                  <div className="py-12 text-center text-white/30 text-xs font-mono border border-dashed border-white/15 rounded-xl bg-navy/30">
                    <Eye size={16} className="mx-auto mb-2 text-white/20 animate-pulse" />
                    No tracking views logged yet
                  </div>
                ) : (
                  <div className="space-y-3 max-h-[480px] overflow-y-auto pr-1 w-full overflow-hidden">
                    {photoViews.map((log) => {
                      let timeStr = "N/A";
                      if (log.createdAt) {
                        try {
                          timeStr = log.createdAt.toDate 
                            ? log.createdAt.toDate().toLocaleString() 
                            : new Date(log.createdAt).toLocaleString();
                        } catch (e) {
                          timeStr = "Logged just now";
                        }
                      }
                      return (
                        <div
                          key={log.id}
                          className="p-3 bg-[#020617]/50 hover:bg-[#020617]/30 rounded-xl border border-white/5 text-[11px] leading-tight flex flex-col gap-1.5 transition-all w-full overflow-hidden break-all"
                        >
                          <div className="flex items-center justify-between">
                            <span className="font-mono text-white/40">{timeStr}</span>
                            <span className="bg-purple-500/15 text-purple-300 font-black border border-purple-500/10 px-1.5 py-0.5 rounded text-[9px] uppercase tracking-wider flex items-center gap-1">
                              <Eye size={10} />
                              Hit #{log.viewCount || 1}
                            </span>
                          </div>

                          <div className="flex items-center justify-between text-white font-serif font-bold text-xs col-span-2">
                            <span className="text-purple-200">Viewed Duration:</span>
                            <span className="text-white font-mono bg-purple-900/30 px-2 py-0.5 rounded border border-purple-500/15 font-black text-[12px] flex items-center gap-0.5 shadow-sm">
                              <Clock size={9} className="text-purple-400 rotate-12" />
                              {log.duration || 0} seconds
                            </span>
                          </div>

                          <table className="w-full border-t border-white/5 pt-1.5 mt-1 text-[10px] font-mono text-white/60 space-y-0.5">
                            <tbody>
                              <tr className="flex justify-between">
                                <td className="text-white/40">Client Timezone:</td>
                                <td className="text-right text-white/80 shrink-0">{log.timezone || "N/A"}</td>
                              </tr>
                              <tr className="flex justify-between">
                                <td className="text-white/40">Resolution:</td>
                                <td className="text-right text-white/80 shrink-0">{log.screenWidth && log.screenHeight ? `${log.screenWidth}x${log.screenHeight}` : "N/A"}</td>
                              </tr>
                              <tr className="flex justify-between">
                                <td className="text-white/40">Referrer URL:</td>
                                <td className="text-right text-white/80 truncate max-w-[150px]" title={log.referrer}>{log.referrer || "Direct Link"}</td>
                              </tr>
                            </tbody>
                          </table>

                          {log.userAgent && (
                            <div className="text-white/40 bg-white/[0.02] p-1 rounded font-mono text-[8px] break-all leading-normal border border-white/[0.01]" title={log.userAgent}>
                              <span className="font-bold text-purple-300/70">Browser UA:</span> {log.userAgent.substring(0, 100)}...
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            </div>
          </div>
        )}
          </>
        ) : (
          <motion.div
        initial={{ opacity: 0, y: 15 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
        className="grid grid-cols-1 md:grid-cols-3 gap-8 items-start w-full"
      >
        {/* Left Column: Avatar dynamic preview with direct file uploader */}
        <div className="md:col-span-1 bg-white/[0.04] border border-white/10 rounded-2xl p-6 shadow-xl relative overflow-hidden flex flex-col items-center text-center">
          <div className="absolute top-0 right-0 w-24 h-24 bg-electric/5 rounded-full blur-xl pointer-events-none" />
          
          <h2 className="font-serif font-bold text-lg text-white mb-4 pb-2 border-b border-white/5 w-full">
            Avatar Preview
          </h2>

          <div className="relative w-40 h-40 sm:w-48 sm:h-48 rounded-full p-1 bg-gradient-to-tr from-sky-400 via-purple-500 to-rose-400 shadow-[0_0_20px_rgba(139,92,246,0.2)] mb-4 overflow-hidden group">
            <div className="w-full h-full rounded-full bg-[#13112b] overflow-hidden relative">
              {editPhotoUrl ? (
                <img
                  src={editPhotoUrl}
                  alt="Avatar preview"
                  className="w-full h-full object-cover object-[center_12%] scale-[2.2] translate-y-[15%] group-hover:scale-[2.4] transition-transform duration-500"
                />
              ) : (
                <div className="w-full h-full bg-white/5 flex items-center justify-center font-mono text-xs text-white/45">
                  No Photo
                </div>
              )}
              {uploadingPhoto && (
                <div className="absolute inset-0 bg-navy/80 flex flex-col items-center justify-center text-xs">
                  <Loader2 className="animate-spin text-electric mb-1" size={24} />
                  <span className="font-bold text-electric text-[10px] uppercase tracking-wider">Uploading...</span>
                </div>
              )}
            </div>
          </div>

          {/* Direct Photo Uploader */}
          <div className="w-full">
            <label className="block w-full py-2.5 px-4 bg-electric hover:bg-electric/90 text-navy font-bold rounded-xl text-center text-xs sm:text-sm cursor-pointer hover:shadow-lg hover:shadow-electric/25 transition-all shadow-md active:scale-95">
              {uploadingPhoto ? "Uploading..." : "Upload New Photo 📷"}
              <input
                type="file"
                accept="image/*"
                onChange={handlePhotoUpload}
                disabled={uploadingPhoto}
                className="hidden"
              />
            </label>
            <p className="text-[10px] text-white/50 mt-2 leading-tight">
              Supports JPEG, PNG, WEBP. Directly overwrites live portrait everywhere.
            </p>
          </div>
        </div>

        {/* Right Column: Editable Biography, Name, & Title profile form */}
        <div className="md:col-span-2 bg-white/[0.04] border border-white/10 rounded-2xl p-6 shadow-xl relative">
          <h2 className="font-serif font-bold text-lg text-white mb-6 pb-2 border-b border-white/5">
            Edit Bio & Text Details
          </h2>

          <form onSubmit={handleSaveProfile} className="space-y-5">
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-white/60 mb-2 font-mono">
                Owner Full Name
              </label>
              <input
                type="text"
                value={editName}
                onChange={(e) => setEditName(e.target.value)}
                placeholder="e.g. Rutvik Dangar"
                className="w-full bg-[#0a071e]/70 border border-white/10 rounded-xl px-4 py-3 text-white placeholder-white/20 focus:outline-none focus:border-electric focus:ring-1 focus:ring-electric transition-all text-sm font-sans"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-white/60 mb-2 font-mono">
                Professional Header Title Focus
              </label>
              <input
                type="text"
                value={editTitle}
                onChange={(e) => setEditTitle(e.target.value)}
                placeholder="e.g. MARKETING × AI × NO-CODE CONSULTANT"
                className="w-full bg-[#0a071e]/70 border border-white/10 rounded-xl px-4 py-3 text-white placeholder-white/20 focus:outline-none focus:border-electric focus:ring-1 focus:ring-electric transition-all text-sm font-sans"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-white/60 mb-2 font-mono">
                Executive Portfolio Bio Statement
              </label>
              <textarea
                rows={4}
                value={editBio}
                onChange={(e) => setEditBio(e.target.value)}
                placeholder="Introduce yourself to agencies and directors..."
                className="w-full bg-[#0a071e]/70 border border-white/10 rounded-xl px-4 py-3 text-white placeholder-white/20 focus:outline-none focus:border-electric focus:ring-1 focus:ring-electric transition-all text-sm font-sans leading-relaxed resize-none"
                required
              />
            </div>

            <div className="pt-2 flex gap-3">
              <button
                type="submit"
                disabled={savingProfile || uploadingPhoto}
                className="flex-1 py-3 px-5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl transition-all shadow-lg active:scale-95 disabled:opacity-50 disabled:scale-100 flex items-center justify-center gap-2 cursor-pointer text-sm font-sans shadow-emerald-500/20"
              >
                {savingProfile ? (
                  <Loader2 size={16} className="animate-spin" />
                ) : (
                  <Check size={16} />
                )}
                Save Profile Settings
              </button>
              <button
                type="button"
                onClick={() => {
                  if (window.confirm("Reset form to default?")) {
                    setEditName(DEFAULT_PROFILE.name);
                    setEditTitle(DEFAULT_PROFILE.title);
                    setEditBio(DEFAULT_PROFILE.bio);
                    setEditPhotoUrl(DEFAULT_PROFILE.photoUrl);
                    addToast("Form values reset. Remember to click save to update live.", "info");
                  }
                }}
                className="px-4 py-3 bg-white/5 hover:bg-white/10 text-white border border-white/10 rounded-xl transition-colors active:scale-95 text-xs font-bold"
              >
                Restore Defaults
              </button>
            </div>
          </form>
        </div>
      </motion.div>
    )}
      </div>

      {/* Global Reset Modal Confirmation */}
      <AnimatePresence>
        {showResetModal && (
          <div className="fixed inset-0 z-[100000] flex items-center justify-center p-4 bg-navy/90 backdrop-blur-md">
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              transition={{ type: 'spring', stiffness: 300, damping: 25 }}
              className="bg-slate-950 border border-white/10 rounded-2xl p-8 max-w-sm w-full shadow-2xl text-center relative"
            >
              <div className="flex justify-center mb-5">
                <div className="w-14 h-14 bg-red-500/20 text-red-500 rounded-xl flex items-center justify-center">
                  <ShieldAlert size={28} className="animate-pulse" />
                </div>
              </div>
              <h2 className="text-2xl font-bold mb-2 font-serif text-white">Reset All Messages</h2>
              <p className="text-white/70 text-sm mb-6 leading-relaxed">
                Are you absolute sure you want to delete <strong className="text-red-400">{messages.length} messages</strong>? This action is permanent and cannot be undone.
              </p>
              <div className="flex gap-3">
                <button
                  onClick={() => {
                    handleResetAllMessages();
                    setShowResetModal(false);
                  }}
                  className="flex-1 bg-red-600 hover:bg-red-700 text-white font-bold py-3.5 rounded-xl transition-all text-sm flex items-center justify-center gap-1.5 shadow-lg active:scale-95 cursor-pointer"
                >
                  <Check size={16} /> Yes, Delete
                </button>
                <button
                  onClick={() => setShowResetModal(false)}
                  className="flex-1 bg-white/10 hover:bg-white/20 text-white font-bold py-3.5 rounded-xl transition-all text-sm flex items-center justify-center gap-1.5 active:scale-95 cursor-pointer"
                >
                  <X size={16} /> Cancel
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
      </motion.div>
    )}
    </AnimatePresence>
  );
}
