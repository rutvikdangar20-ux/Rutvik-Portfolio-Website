import React from "react";

export default function PlainAmbientSlide() {
  return (
    <section 
      className="relative w-full h-[100vh] bg-[#03020c] overflow-hidden flex items-center justify-center border-t border-white/5"
      id="plain-ambient-artwork"
      style={{ contentVisibility: "auto" }}
    >
      {/* Base premium black space */}
      <div className="absolute inset-0 bg-[#03020c] pointer-events-none" />

      {/* Shimmering mesh glows mixing the colors beautifully */}
      {/* 1. Deep Light Blue celestial flare */}
      <div className="absolute -top-[10%] left-[5%] w-[65vw] h-[65vw] max-w-[900px] max-h-[900px] rounded-full bg-sky-400/15 blur-[140px] animate-wave-ambient-1 pointer-events-none" />

      {/* 2. Mystical Purple neon core */}
      <div className="absolute top-[20%] right-[5%] w-[65vw] h-[65vw] max-w-[950px] max-h-[950px] rounded-full bg-purple-600/15 blur-[150px] animate-wave-ambient-2 pointer-events-none" />

      {/* 3. Warm Peach (piche) sunset bloom */}
      <div className="absolute -bottom-[15%] left-[20%] w-[55vw] h-[55vw] max-w-[800px] max-h-[800px] rounded-full bg-[#fca5a5]/15 blur-[130px] animate-wave-ambient-3 pointer-events-none" />

      {/* Dark vignette blending for organic visual buttery harmony */}
      <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-transparent to-black pointer-events-none" />
    </section>
  );
}
