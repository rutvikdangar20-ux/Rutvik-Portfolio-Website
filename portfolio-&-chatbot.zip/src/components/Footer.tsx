import React, { useState, useEffect, useRef } from "react";
import { ArrowUp, Clock, Volume2, VolumeX, Eye } from "lucide-react";
import { audioSynth } from "../utils/audio";
import { db } from "./firebase";
import { doc, setDoc, onSnapshot, increment } from "firebase/firestore";

enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
  }
}

function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: null,
      email: null,
      emailVerified: null,
      isAnonymous: null,
    },
    operationType,
    path
  };
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

export default function Footer() {
  const [ahmedabadTime, setAhmedabadTime] = useState("");
  const [isAdminDelaying, setIsAdminDelaying] = useState(false);
  const [isMuted, setIsMuted] = useState(audioSynth.isMuted());
  const [visitorCount, setVisitorCount] = useState<number | null>(null);

  const lastClickTimeRef = useRef<number>(0);
  const clickTimerRef = useRef<NodeJS.Timeout | null>(null);
  const soundTimerRef = useRef<NodeJS.Timeout | null>(null);
  const redirectTimerRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    // Unique visitor counter tracking via Firestore
    const trackVisitor = async () => {
      const docPath = "stats/visitor_counter";
      try {
        const docRef = doc(db, "stats", "visitor_counter");
        await setDoc(docRef, { count: increment(1) }, { merge: true });
      } catch (err) {
        console.error("Error setting/incrementing visitor count:", err);
        handleFirestoreError(err, OperationType.WRITE, docPath);
      }
    };

    trackVisitor();

    // Subscribe to real-time spectator visitor tracking
    const docPath = "stats/visitor_counter";
    const docRef = doc(db, "stats", "visitor_counter");
    const unsub = onSnapshot(docRef, (docSnap) => {
      if (docSnap.exists()) {
        setVisitorCount(docSnap.data().count || 0);
      } else {
        // Create matching fallback document if not populated
        setDoc(docRef, { count: 1 }, { merge: true }).catch((e) => {
          handleFirestoreError(e, OperationType.WRITE, docPath);
        });
        setVisitorCount(1);
      }
    }, (error) => {
      console.error("Visitor count subscription error:", error);
      handleFirestoreError(error, OperationType.GET, docPath);
    });

    return () => unsub();
  }, []);

  useEffect(() => {
    // Listen to mute changes globally
    const unsubscribe = audioSynth.subscribe((muted) => {
      setIsMuted(muted);
    });
    return () => unsubscribe();
  }, []);

  useEffect(() => {
    const updateTimeString = () => {
      try {
        const formatter = new Intl.DateTimeFormat("en-US", {
          timeZone: "Asia/Kolkata",
          hour: "2-digit",
          minute: "2-digit",
          second: "2-digit",
          hour12: true,
        });
        setAhmedabadTime(formatter.format(new Date()));
      } catch (error) {
        // Fallback if timezone not supported
        setAhmedabadTime(new Date().toLocaleTimeString());
      }
    };

    updateTimeString();
    const intervalId = setInterval(updateTimeString, 1000);
    return () => clearInterval(intervalId);
  }, []);

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  };


  return (
    <footer className="bg-navy text-white/80 py-12 px-6 relative" id="main-footer-ref">
      {/* Absolute extension to cover any bottom rubber-band elastic bouncing with dark navy */}
      <div className="absolute top-full left-0 right-0 h-[1000px] bg-navy pointer-events-none" />
      <div className="max-w-6xl mx-auto flex flex-col md:flex-row items-center justify-between gap-6">
        <div className="text-center md:text-left flex flex-col items-center md:items-start gap-4">
          <div>
            <h4 className="font-serif text-2xl font-bold text-white mb-2">
              Rutvik Dangar
            </h4>
            <p className="text-electric font-medium text-sm tracking-wider uppercase">
              Marketing × AI × No-Code
            </p>
          </div>
        </div>

        <div className="flex flex-col items-center gap-3">
          {/* Dynamic real-time Clock */}
          <div 
            className="flex items-center gap-2 px-4 py-2 rounded-full bg-white/5 border border-white/15 text-xs text-white shadow-inner font-mono tracking-wide" 
            id="local-clock"
          >
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
            </span>
            <span className="text-white/50 flex items-center gap-1">
              <Clock size={12} /> Clock:
            </span>
            <span className="text-electric font-bold">{ahmedabadTime}</span>
          </div>

          {/* Real-time Unique Visitor Pill */}
          <div 
            className="flex items-center gap-2 px-4 py-2 rounded-full bg-white/5 border border-white/15 text-xs text-white shadow-inner font-mono tracking-wide animate-none"
            id="visitor-counter-pill"
          >
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-electric opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-electric"></span>
            </span>
            <span className="text-white/50 flex items-center gap-1">
              <Eye size={12} className="text-white/60" /> Views:
            </span>
            <span className="text-electric font-bold">
              {visitorCount !== null ? (visitorCount + 2000).toLocaleString() : "..."}
            </span>
          </div>

          <div className="text-center text-sm opacity-60">
            © {new Date().getFullYear()}{" "}
            <a
              href="/admin/messages"
              onClick={(e) => {
                e.preventDefault();
                const now = Date.now();
                const diff = now - lastClickTimeRef.current;

                if (diff < 350) {
                  // DOUBLE TAP DETECTED - Cancel any pending action completely!
                  if (clickTimerRef.current) {
                    clearTimeout(clickTimerRef.current);
                    clickTimerRef.current = null;
                  }
                  if (soundTimerRef.current) {
                    clearTimeout(soundTimerRef.current);
                    soundTimerRef.current = null;
                  }
                  if (redirectTimerRef.current) {
                    clearTimeout(redirectTimerRef.current);
                    redirectTimerRef.current = null;
                  }
                  setIsAdminDelaying(false);
                  audioSynth.playClick();
                  lastClickTimeRef.current = now;
                  return;
                }

                lastClickTimeRef.current = now;

                if (clickTimerRef.current) clearTimeout(clickTimerRef.current);
                if (soundTimerRef.current) clearTimeout(soundTimerRef.current);
                if (redirectTimerRef.current) clearTimeout(redirectTimerRef.current);

                clickTimerRef.current = setTimeout(() => {
                  setIsAdminDelaying(true);
                  // Initial subtle transition click
                  audioSynth.playClick();

                  // At exactly 1st second (1000ms delay) -> play the water droplet sound
                  soundTimerRef.current = setTimeout(() => {
                    audioSynth.playWaterDrop();
                  }, 1000);

                  // At exactly 2nd second (2000ms delay) -> open the Admin page
                  redirectTimerRef.current = setTimeout(() => {
                    window.history.pushState({}, "", "/admin/messages");
                    window.dispatchEvent(new Event("pushstate-nav"));
                    setIsAdminDelaying(false);
                  }, 2000);
                }, 350); // Double-click threshold
              }}
              className={`hover:underline cursor-pointer font-semibold transition-all duration-1000 ${
                isAdminDelaying
                  ? "text-white/20 select-none cursor-default"
                  : "text-white hover:text-electric"
              }`}
            >
              Rutvik Dangar
            </a>
            . All rights reserved.
          </div>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => {
              const nextMuted = !isMuted;
              audioSynth.setMuted(nextMuted);
              setIsMuted(nextMuted);
              if (!nextMuted) {
                audioSynth.playClick();
              }
            }}
            className="w-12 h-12 rounded-full border border-white/20 flex items-center justify-center hover:bg-white/10 hover:text-white transition-all cursor-pointer"
            title={isMuted ? "Unmute Sound Feedback" : "Mute Sound Feedback"}
            id="sound-mute-toggle-btn"
          >
            {isMuted ? (
              <VolumeX size={18} className="text-white/40" />
            ) : (
              <Volume2 size={18} className="text-electric animate-pulse" />
            )}
          </button>

          <button
            onClick={() => {
              audioSynth.playClick();
              scrollToTop();
            }}
            className="w-12 h-12 rounded-full border border-white/20 flex items-center justify-center hover:bg-white/10 hover:text-white transition-colors cursor-pointer"
            aria-label="Back to top"
            id="back-to-top-btn"
          >
            <ArrowUp size={18} />
          </button>
        </div>
      </div>
    </footer>
  );
}
