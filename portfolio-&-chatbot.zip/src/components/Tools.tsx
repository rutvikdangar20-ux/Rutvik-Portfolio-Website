import { useState } from "react";
import { 
  Bot, 
  Sparkles, 
  Code2, 
  Layers, 
  Workflow, 
  PenTool, 
  ShoppingBag, 
  FileSpreadsheet, 
  ArrowRight,
  Terminal,
  Activity,
  CheckCircle,
  Zap,
  X
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import CountUp from "./CountUp";
import { audioSynth } from "../utils/audio";

interface ToolItem {
  name: string;
  category: string;
  icon: React.ReactNode;
  desc: string;
  project: string;
  color: string;
  textClass: string;
  accentClass: string;
  iconColorClass: string;
  mastery: number;
  useCase: string;
  highlights: string[];
}

export default function Tools() {
  const tools: ToolItem[] = [
    {
      name: "ChatGPT",
      category: "GenAI & LLMs",
      icon: <Bot size={28} />,
      desc: "Deploys extensively for immediate contextual ideation, modeling tactical B2B outreach scripts, and detailing structural flowcharts for high-converting marketing pages.",
      project: "Big Bite MVP & Agency",
      color: "#10b981", 
      textClass: "text-emerald-500",
      accentClass: "from-emerald-500/10 to-teal-500/5 border-emerald-500/20 hover:border-emerald-500/40",
      iconColorClass: "bg-emerald-500/10 text-emerald-500 group-hover:bg-emerald-500 group-hover:text-white",
      mastery: 95,
      useCase: "Prompt Design & Strategy Planning",
      highlights: ["Tactical Persona Building", "Multi-Stage Ideation", "High-Converting Page Copy"]
    },
    {
      name: "Claude",
      category: "GenAI & LLMs",
      icon: <Sparkles size={28} />,
      desc: "Serves as the core sandbox for sophisticated reasoning prompts, structuring hierarchical document parsers, and formulating precise brand communication tones.",
      project: "ANANTA Platform",
      color: "#f59e0b",
      textClass: "text-amber-500",
      accentClass: "from-amber-500/10 to-orange-500/5 border-amber-500/20 hover:border-amber-500/40",
      iconColorClass: "bg-amber-500/10 text-amber-500 group-hover:bg-amber-500 group-hover:text-white",
      mastery: 93,
      useCase: "Deep Code & Logic Mapping",
      highlights: ["Recursive Instruction Styling", "Nuanced Long-form Writing", "System Instruction Frameworks"]
    },
    {
      name: "Gemini / AI Studio",
      category: "Multimodal AI",
      icon: <Code2 size={28} />,
      desc: "Utilized to orchestrate powerful server-side API endpoints, multi-modal context queries, and secure integration backends to enable dynamic real-time features.",
      project: "Portfolio AI Assistant",
      color: "#3b82f6",
      textClass: "text-blue-500",
      accentClass: "from-blue-500/10 to-indigo-500/5 border-blue-500/20 hover:border-blue-500/40",
      iconColorClass: "bg-blue-500/10 text-blue-500 group-hover:bg-blue-500 group-hover:text-white",
      mastery: 94,
      useCase: "Developer Prototyping & Backend APIs",
      highlights: ["Structured JSON Generation", "Multimodal Context Parsing", "Secure API Orchestrations"]
    },
    {
      name: "OutSystems",
      category: "Low-Code Enterprise",
      icon: <Layers size={28} />,
      desc: "Leveraged to architect transaction-rich enterprise architectures, construct fast schemas, and quickly deliver scalable MVP architectures to production.",
      project: "General Cloud Prototyping",
      color: "#ef4444",
      textClass: "text-red-500",
      accentClass: "from-red-500/10 to-rose-500/5 border-red-500/20 hover:border-red-500/40",
      iconColorClass: "bg-red-500/10 text-red-500 group-hover:bg-red-500 group-hover:text-white",
      mastery: 89,
      useCase: "Enterprise Application Logic",
      highlights: ["Scalable Data Modeling", "Service-Studio Integrations", "Speedy UI Layout Delivery"]
    },
    {
      name: "n8n AI",
      category: "AI Workflow Automations",
      icon: <Workflow size={28} />,
      desc: "My ultimate playground for building complex multi-step webhooks, parsing unstructured live emails, and designing automated data routing pipelines.",
      project: "Bento Automations Network",
      color: "#f97316",
      textClass: "text-orange-500",
      accentClass: "from-orange-500/10 to-red-500/5 border-orange-500/20 hover:border-orange-500/40",
      iconColorClass: "bg-orange-500/10 text-orange-500 group-hover:bg-orange-500 group-hover:text-white",
      mastery: 92,
      useCase: "Event Driven Integration Loops",
      highlights: ["Webhook Routing Schemes", "Dynamic JSON Mapping", "API Node Chains & Flows"]
    },
    {
      name: "Framer",
      category: "UX/UI Prototyping",
      icon: <PenTool size={28} />,
      desc: "Integrated as the primary platform for crafting butter-smooth interactive frontends, micro-interactions, and premium layouts without writing boilerplate structures.",
      project: "Visual Agency Templates",
      color: "#ec4899",
      textClass: "text-pink-500",
      accentClass: "from-pink-500/10 to-purple-500/5 border-pink-500/20 hover:border-pink-500/40",
      iconColorClass: "bg-pink-500/10 text-pink-500 group-hover:bg-pink-500 group-hover:text-white",
      mastery: 88,
      useCase: "Premium Responsive Frontends",
      highlights: ["Advanced Layout Transitions", "Custom Component Modeling", "Interactive Animation Nodes"]
    },
    {
      name: "Shopify",
      category: "E-Commerce Systems",
      icon: <ShoppingBag size={28} />,
      desc: "Deployed to engineer custom storefront checkouts, streamline product indexing pipelines, and execute data-backed SEO mappings to capture direct retail funnels.",
      project: "Corporate Retail Outlets",
      color: "#16a34a",
      textClass: "text-green-500",
      accentClass: "from-green-500/10 to-emerald-500/5 border-green-500/20 hover:border-green-500/40",
      iconColorClass: "bg-green-500/10 text-green-500 group-hover:bg-green-500 group-hover:text-white",
      mastery: 87,
      useCase: "Commercial Conversion Pipelines",
      highlights: ["Conversion Path Auditing", "Metafield Database Models", "SEO & Copy Coordination"]
    },
    {
      name: "MS Excel (Adv)",
      category: "Data Structuring & Analysis",
      icon: <FileSpreadsheet size={28} />,
      desc: "Utilized for modeling analytical pivots, compiling and scrubbing clinical data frames, and automating multi-tiered pricing spreadsheets for business validation.",
      project: "CLASM Clinical Project",
      color: "#059669",
      textClass: "text-emerald-600",
      accentClass: "from-emerald-600/10 to-teal-600/5 border-emerald-600/20 hover:border-emerald-600/40",
      iconColorClass: "bg-emerald-600/10 text-emerald-600 group-hover:bg-emerald-600 group-hover:text-white",
      mastery: 90,
      useCase: "Diagnostic Models & Logic Arrays",
      highlights: ["Array Nested Formulations", "Interactive Pivot Charts", "Clean Statistical Summaries"]
    }
  ];

  const [activeTool, setActiveTool] = useState<ToolItem>(tools[2]); // Default Gemini
  const [isModalOpen, setIsModalOpen] = useState(false);

  return (
    <section id="tools" className="py-24 px-6 relative bg-transparent overflow-hidden border-t border-navy/5">
      {/* Absolute Decorative Glow Mesh */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden opacity-30">
        <div className="absolute top-[20%] left-[10%] w-[450px] h-[450px] rounded-full bg-violet-600/5 blur-[120px]" />
        <div className="absolute -bottom-[10%] right-[5%] w-[400px] h-[400px] rounded-full bg-emerald-500/5 blur-[100px]" />
      </div>

      <div className="max-w-6xl mx-auto relative z-10">
        <div className="mb-16 md:flex md:items-end md:justify-between gap-8">
          <div>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-navy/5 text-navy rounded-full text-xs font-bold tracking-wider uppercase mb-4 border border-navy/5">
              <Zap size={12} className="text-electric animate-pulse" /> Core Infrastructure
            </div>
            <h2 className="font-serif text-3xl md:text-5xl font-bold text-navy mb-4">
              Tools & Technologies
            </h2>
            <p className="text-charcoal text-lg max-w-2xl">
              An interactive overview of how I deploy advanced LLM suites, low-code systems, 
              and data analyzers to ship functional products from the ground up. Tap any stack to launch diagnostics.
            </p>
          </div>
          <div className="hidden md:block shrink-0">
            <span className="inline-flex items-center gap-2 bg-navy/5 text-navy px-4 py-2 rounded-full text-sm font-bold border border-navy/10 shadow-sm">
              <Sparkles size={16} className="text-electric" /> Power Builder Mode
            </span>
          </div>
        </div>

        {/* Full-Width Launchpad Grid */}
        <div className="max-w-5xl mx-auto">
          <p className="text-xs font-bold text-navy/40 uppercase tracking-widest mb-6 flex items-center justify-center gap-1.5 text-center">
            <Terminal size={14} className="text-electric animate-pulse" /> Interactive Launchpad (Tap to launch Diagnostics)
          </p>
          
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-6">
            {tools.map((tool) => {
              const isActive = activeTool.name === tool.name;
              return (
                <motion.div
                  key={tool.name}
                  onClick={() => {
                    setActiveTool(tool);
                  }}
                  whileHover={{ scale: 1.05, y: -4 }}
                  whileTap={{ scale: 0.98 }}
                  className="relative p-6 rounded-3xl cursor-pointer transition-all duration-300 flex flex-col items-center justify-center text-center border bg-white/60 backdrop-blur-sm border-navy/5 hover:bg-white shadow-sm hover:shadow-xl hover:border-transparent"
                  style={{
                    boxShadow: `0 8px 24px -6px rgba(15, 23, 42, 0.04)`
                  }}
                >
                  {/* Brand-Specific Micro Glowing Dot */}
                  <div
                    className="absolute top-4 right-4 w-2 h-2 rounded-full"
                    style={{ backgroundColor: tool.color }}
                  />

                  {/* Icon Orb */}
                  <div className="w-14 h-14 rounded-2xl flex items-center justify-center mb-4 transition-colors duration-300 bg-navy/5 text-navy"
                  style={{ backgroundColor: `${tool.color}15`, color: tool.color }}
                  >
                    {tool.icon}
                  </div>

                  {/* Name */}
                  <span className="font-bold text-navy text-sm md:text-base">
                    {tool.name}
                  </span>
                  <span className="text-[10px] text-charcoal/40 font-semibold uppercase tracking-wider mt-1 block">
                    {tool.category}
                  </span>
                  
                  <span 
                    onClick={(e) => {
                      e.stopPropagation();
                      audioSynth.playOpenSwell();
                      setActiveTool(tool);
                      setIsModalOpen(true);
                    }}
                    className="text-[10px] text-electric font-bold uppercase tracking-wide mt-3 inline-flex items-center gap-0.5 cursor-pointer border border-electric/20 hover:border-electric/40 bg-electric/5 hover:bg-electric/15 px-2.5 py-1 rounded-lg transition-colors"
                  >
                    Launch ➜
                  </span>
                </motion.div>
              );
            })}
          </div>

          {/* Quick Context Help */}
          <div className="mt-10 p-5 bg-navy/[0.02] border border-navy/5 rounded-2xl flex items-center justify-center gap-3 text-center max-w-2xl mx-auto">
            <Activity size={18} className="text-electric shrink-0 animate-pulse" />
            <p className="text-xs text-charcoal/70 leading-relaxed">
              Tapping on any technology node automatically deploys and initialises System: Live Diagnostic simulation inside an animated pop-up modal.
            </p>
          </div>
        </div>
      </div>

      {/* Modern Pop-Up Modal Dynamic Details Terminal */}
      <AnimatePresence>
        {isModalOpen && (
          <div className="fixed inset-0 z-[10000] flex items-center justify-center p-4">
            {/* Backdrop Blur Overlay with click handling */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => {
                audioSynth.playCloseSwell();
                setIsModalOpen(false);
              }}
              className="fixed inset-0 bg-navy/60 backdrop-blur-md cursor-pointer"
            />

            {/* Modal Card content Container */}
            <motion.div
              initial={{ opacity: 0, scale: 0.9, y: 30 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 30 }}
              transition={{ type: "spring", damping: 25, stiffness: 220 }}
              className="bg-[#0b1320] text-white p-6 md:p-8 rounded-3xl shadow-3xl max-w-lg w-full relative z-10 flex flex-col overflow-hidden max-h-[92vh] overflow-y-auto border border-white/5"
              data-lenis-prevent
            >
              {/* Telemetry Matrix Pattern overlay */}
              <div className="absolute inset-0 pointer-events-none opacity-[0.03] bg-[linear-gradient(rgba(18,24,38,0.4)_1px,transparent_1px),linear-gradient(90deg,rgba(18,24,38,0.4)_1px,transparent_1px)] bg-[size:16px_16px]" />

              {/* Close Button Cross Icon ❌ with red glow */}
              <button
                onClick={() => {
                  audioSynth.playCloseSwell();
                  setIsModalOpen(false);
                }}
                className="absolute top-5 right-5 p-2 rounded-full text-white/70 hover:text-red-500 hover:bg-white/5 bg-white/5 transition-all duration-300 z-50 flex items-center justify-center hover:scale-110 active:scale-90"
                aria-label="Close modal"
              >
                <X size={20} className="stroke-[2.5px]" />
              </button>

              <div className="relative z-10 flex flex-col h-full justify-between mt-2">
                <div>
                  {/* Header bar */}
                  <div className="flex items-center justify-between pb-5 border-b border-white/5 mb-6">
                    <div className="flex items-center gap-2.5">
                      <span 
                        className="w-2.5 h-2.5 rounded-full" 
                        style={{ backgroundColor: activeTool.color, boxShadow: `0 0 10px ${activeTool.color}` }}
                      />
                      <span className="font-mono text-xs text-white/50 tracking-widest uppercase">System: Live Diagnostic</span>
                    </div>
                    <span className="font-mono text-xs text-white/30 uppercase tracking-wider mr-10">{activeTool.category}</span>
                  </div>

                  {/* Meta Section */}
                  <div className="flex items-start gap-4 mb-5">
                    <div 
                      className="w-14 h-14 rounded-2xl flex items-center justify-center shrink-0"
                      style={{ backgroundColor: `${activeTool.color}20`, color: activeTool.color }}
                    >
                      {activeTool.icon}
                    </div>

                    <div>
                      <h3 className="text-2xl font-black font-sans tracking-tight text-white flex items-center gap-2">
                        {activeTool.name}
                      </h3>
                      <p className="text-xs font-semibold text-white/40 uppercase tracking-wider mt-1">
                        Focus: <span className="text-white/80 font-bold">{activeTool.useCase}</span>
                      </p>
                    </div>
                  </div>

                  {/* Experience Summary */}
                  <p className="text-white/70 text-sm md:text-base leading-relaxed mb-6 font-medium">
                    {activeTool.desc}
                  </p>

                  {/* Visual Proficiency Bar */}
                  <div className="mb-6 bg-white/5 p-4 rounded-2xl border border-white/5">
                    <div className="flex justify-between text-xs font-mono font-bold text-white/50 mb-2">
                      <span>UTILITY INDEX</span>
                      <span style={{ color: activeTool.color }}>
                        <CountUp end={activeTool.mastery} suffix="%" /> MAX CAPACITY
                      </span>
                    </div>
                    <div className="w-full bg-white/5 h-2 rounded-full overflow-hidden">
                      <motion.div
                        initial={{ width: 0 }}
                        animate={{ width: `${activeTool.mastery}%` }}
                        transition={{ duration: 1.0, ease: "easeOut" }}
                        className="h-full rounded-full"
                        style={{ backgroundColor: activeTool.color }}
                      />
                    </div>
                  </div>

                  {/* Bullet Highlights */}
                  <div className="space-y-2.5 mb-8">
                    <span className="text-[10px] font-bold text-white/40 uppercase tracking-widest block mb-1">Impact Highlights</span>
                    {activeTool.highlights.map((highlight) => (
                      <div key={highlight} className="flex items-center gap-2.5 text-xs text-white/80">
                        <CheckCircle className="shrink-0 w-4 h-4 text-emerald-400" />
                        <span className="font-medium">{highlight}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Impact Project Footer */}
                <div className="pt-5 border-t border-white/5 mt-auto flex items-center justify-between">
                  <div>
                    <span className="text-[10px] font-semibold text-white/30 uppercase tracking-wider block">Historic Deployment</span>
                    <span className="text-sm font-bold text-white tracking-wide">{activeTool.project}</span>
                  </div>

                  <a 
                    href="#projects" 
                    onClick={() => setIsModalOpen(false)}
                    className="inline-flex items-center gap-1 text-xs font-bold uppercase tracking-wider py-2 px-3 bg-white/5 hover:bg-white/10 rounded-xl transition-all duration-300"
                    style={{ color: activeTool.color }}
                  >
                    Audit Projects <ArrowRight size={14} className="ml-1" />
                  </a>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </section>
  );
}
