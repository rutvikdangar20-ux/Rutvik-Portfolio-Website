import React, { useEffect, useState, useRef } from "react";
import { X, Briefcase, Sparkles } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { db, useProfile } from "./firebase";
import { collection, addDoc, serverTimestamp, doc, setDoc, increment } from "firebase/firestore";

interface ProfessionalPhotoModalProps {
  isOpen: boolean;
  onClose: () => void;
  sessionCount: number;
}

export default function ProfessionalPhotoModal({ isOpen, onClose, sessionCount }: ProfessionalPhotoModalProps) {
  const { profile } = useProfile();
  const [activeSeconds, setActiveSeconds] = useState(0);
  const [isLightboxOpen, setIsLightboxOpen] = useState(false);
  const openTimeRef = useRef<number | null>(null);
  const timerIntervalRef = useRef<any>(null);

  useEffect(() => {
    if (isOpen) {
      openTimeRef.current = Date.now();
      setActiveSeconds(0);
      
      // Increment persistent counter in Firestore stats/photo_view_counter
      try {
        const counterRef = doc(db, "stats", "photo_view_counter");
        setDoc(counterRef, { count: increment(1) }, { merge: true })
          .catch((e) => console.error("Error updating photo view counter in Firestore:", e));
      } catch (err) {
        console.error("Failed to update photo view counter in Firestore:", err);
      }
      
      // Start active timer to track duration (displayed only in admin)
      timerIntervalRef.current = setInterval(() => {
        setActiveSeconds((prev) => prev + 1);
      }, 1000);
    } else {
      if (openTimeRef.current) {
        const duration = ((Date.now() - openTimeRef.current) / 1000).toFixed(1);
        const numDuration = Number(duration);
        const referrerVal = document.referrer || "Direct Portfolio";
        const timezoneVal = Intl.DateTimeFormat().resolvedOptions().timeZone || "Unknown Zone";
        const langVal = navigator.language || "en-US";
        const wVal = window.innerWidth;
        const hVal = window.innerHeight;

        // 1. Silently write telemetry log to Firestore for real-time Admin lookup
        try {
          addDoc(collection(db, "photo_views"), {
            duration: numDuration,
            viewCount: sessionCount,
            timezone: timezoneVal,
            screenWidth: wVal,
            screenHeight: hVal,
            referrer: referrerVal,
            language: langVal,
            createdAt: serverTimestamp(),
            userAgent: navigator.userAgent || "Unknown Browser",
          }).catch((err) => console.error("Firestore telemetry save failed:", err));
        } catch (fErr) {
          console.error("Firestore write failure:", fErr);
        }
        
        // 2. Silently report the engagement to the server in the background for mail notifications
        fetch("/api/track-photo-view", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            duration: numDuration,
            viewCount: sessionCount,
            timezone: timezoneVal,
            screenWidth: wVal,
            screenHeight: hVal,
            referrer: referrerVal,
            language: langVal,
          }),
        }).catch((err) => {
          // completely silent fallback to keep user experience perfect
          console.warn("Silent tracking update complete:", err);
        });
      }

      if (timerIntervalRef.current) {
        clearInterval(timerIntervalRef.current);
      }
      openTimeRef.current = null;
    }

    return () => {
      if (timerIntervalRef.current) {
        clearInterval(timerIntervalRef.current);
      }
    };
  }, [isOpen, sessionCount]);

  if (!isOpen) return null;

  return (
    <div 
      className="fixed inset-0 z-[99999] flex items-center justify-center p-4 bg-navy/60 backdrop-blur-xl"
      id="professional-photo-modal-overlay"
    >
      {/* Background click to dismiss */}
      <div className="absolute inset-0" onClick={onClose} />

      <motion.div
        initial={{ opacity: 0, scale: 0.92, y: 15 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 10 }}
        transition={{ type: "spring", damping: 25, stiffness: 350 }}
        className="relative w-full max-w-md bg-white border border-rose-500/10 rounded-3xl shadow-[0_20px_60px_rgba(9,24,76,0.18)] overflow-hidden z-10 flex flex-col"
        id="professional-photo-card"
      >
        {/* Colorful gradient header decoration */}
        <div className="h-2 bg-gradient-to-r from-sky-400 via-purple-500 to-rose-400" />

        {/* Close Button top-right */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 bg-charcoal/5 hover:bg-rose-500/10 text-charcoal hover:text-rose-600 rounded-full transition-all hover:rotate-90 shadow-xs cursor-pointer z-20"
          aria-label="Close professional photo popup"
          id="photo-modal-close-btn"
        >
          <X size={18} />
        </button>

        <div className="p-6 flex flex-col items-center text-center">
          {/* Decorative Sparkle Label */}
          <div className="flex items-center gap-1.5 px-3 py-1 bg-[#f5f3ff] rounded-full text-[11px] font-black text-purple-700 tracking-wider uppercase mb-5 shadow-xs">
            <Sparkles size={11} className="animate-spin" />
            <span>EXECUTIVE PROFILE PORTRAIT</span>
          </div>

          {/* Picture Box with dynamic ring glow - Clicking opens full scale view */}
          <div 
            onClick={() => setIsLightboxOpen(true)}
            className="relative w-52 h-52 sm:w-60 sm:h-60 rounded-full p-1 bg-gradient-to-tr from-sky-400 via-purple-500 to-rose-400 shadow-[0_0_20px_rgba(139,92,246,0.15)] mb-2 overflow-hidden group cursor-pointer hover:scale-105 transition-all duration-300"
            title="Click to view full uncropped photo 👁️"
            id="photo-modal-avatar-container"
          >
            <div className="w-full h-full rounded-full bg-white overflow-hidden relative">
              {/* Rutvik's Dynamic Profile Photo - Centered nicely around the face with tight zoom */}
              <img
                src={profile.photoUrl}
                alt={`${profile.name} - Professional Headshot`}
                className="w-full h-full object-cover object-[center_12%] scale-[2.4] translate-y-[15%] group-hover:scale-[2.6] transition-transform duration-700 pointer-events-none"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/30 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-end justify-center pb-4 text-[10px] font-bold text-white tracking-widest uppercase">
                <span>View Full Size 👁️</span>
              </div>
            </div>
          </div>

          <p className="text-[10px] font-bold text-ash/60 text-purple-600/70 tracking-wide mb-4 animate-pulse select-none">
            Click picture to view complete full-body photo
          </p>

          {/* Rutvik's Name & Credentials */}
          <h2 className="text-2xl font-serif font-black text-navy tracking-tight mb-1" id="photo-modal-title">
            {profile.name}
          </h2>
          <p className="text-xs font-mono font-bold text-electric uppercase tracking-wider mb-4 flex items-center justify-center gap-1">
            <Briefcase size={12} /> {profile.title}
          </p>

          <p className="text-xs text-charcoal/80 leading-relaxed max-w-sm mb-4 font-sans">
            "{profile.bio}"
          </p>
        </div>
      </motion.div>

      {/* Complete Resolution Photo Lightbox Overlay */}
      <AnimatePresence>
        {isLightboxOpen && (
          <div 
            className="fixed inset-0 z-[1000000] flex flex-col items-center justify-center p-4 bg-navy/95 backdrop-blur-3xl animate-in fade-in duration-300"
            id="fullscreen-lightbox-overlay"
          >
            {/* Background click to dismiss */}
            <div className="absolute inset-0 cursor-zoom-out" onClick={() => setIsLightboxOpen(false)} />

            {/* Close Button top-right */}
            <button
              onClick={() => setIsLightboxOpen(false)}
              className="absolute top-6 right-6 p-3 bg-white/10 hover:bg-rose-500 hover:text-white text-white/90 rounded-full transition-all hover:rotate-90 shadow-lg cursor-pointer z-50 text-sm font-bold flex items-center gap-1.5"
              aria-label="Close full size view"
              id="fullscreen-close-btn"
            >
              <X size={20} />
            </button>

            {/* Main Lightbox Content - Complete uncropped portrait layout */}
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              transition={{ type: "spring", damping: 25, stiffness: 280 }}
              className="relative max-w-[90vw] max-h-[80vh] flex flex-col items-center justify-center z-40 select-none"
              id="fullscreen-img-container"
            >
              <img
                src={profile.photoUrl}
                alt={`${profile.name} - Original Complete Photo`}
                className="max-h-[70vh] max-w-full rounded-2xl object-contain shadow-[0_25px_60px_rgba(0,0,0,0.8)] border border-white/10"
                referrerPolicy="no-referrer"
              />
              
              {/* Elegant caption for brand accent */}
              <div className="text-center mt-6">
                <p className="text-white font-serif font-black text-lg sm:text-xl tracking-wide">
                  {profile.name}
                </p>
                <p className="text-[#a855f7] font-mono text-[9px] uppercase tracking-widest mt-1 font-bold">
                  {profile.title}
                </p>
                <p className="text-white/40 text-[8px] uppercase tracking-wider mt-2.5">
                  Click outer space or close button to return
                </p>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
