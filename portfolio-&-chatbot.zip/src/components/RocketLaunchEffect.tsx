import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { db } from "./firebase";
import { doc, onSnapshot, setDoc, increment } from "firebase/firestore";
import { audioSynth } from "../utils/audio";

interface FlyingRocket {
  id: number;
  left: number;
  scale: number;
}

export default function RocketLaunchEffect() {
  const [rockets, setRockets] = useState<FlyingRocket[]>([]);
  const [rocketCount, setRocketCount] = useState<number | null>(null);

  useEffect(() => {
    // Keep real-time sync of rocket count with Firestore
    const docRef = doc(db, "stats", "rocket_counter");
    const unsub = onSnapshot(
      docRef,
      (docSnap) => {
        if (docSnap.exists()) {
          setRocketCount(docSnap.data().count || 0);
          // Dispatch custom event to notify Header and other components in real time
          window.dispatchEvent(
            new CustomEvent("rocket-count-updated", {
              detail: { count: docSnap.data().count || 0 },
            })
          );
        } else {
          // Initialize counter document if missing
          setDoc(docRef, { count: 0 }, { merge: true }).catch((err) =>
            console.error("Error creating rocket counter doc:", err)
          );
          setRocketCount(0);
        }
      },
      (error) => {
        console.error("Rocket counter subscription error:", error);
      }
    );

    return () => unsub();
  }, []);

  useEffect(() => {
    // Listen to local launch-rocket events
    const handleLaunch = () => {
      // Play high quality synthesized rocket launch sound
      audioSynth.playRocketLaunch();

      // Spawn a new rocket with randomized center offset and custom subtle scaling
      const newRocket: FlyingRocket = {
        id: Date.now() + Math.random(),
        left: 36 + Math.random() * 28, // Center-focused random positioning (36% to 64% of viewport)
        scale: 0.72 + Math.random() * 0.28, // Slighly smaller, extremely elegant scale
      };

      setRockets((prev) => [...prev, newRocket]);

      // Increment Firestore global rocket counter
      const docRef = doc(db, "stats", "rocket_counter");
      setDoc(docRef, { count: increment(1) }, { merge: true }).catch((err) =>
        console.error("Error incrementing rocket count:", err)
      );
    };

    window.addEventListener("launch-rocket", handleLaunch);
    return () => window.removeEventListener("launch-rocket", handleLaunch);
  }, []);

  const removeRocket = (id: number) => {
    setRockets((prev) => prev.filter((r) => r.id !== id));
  };

  return (
    <div className="fixed inset-0 pointer-events-none z-[100000] overflow-hidden">
      <AnimatePresence>
        {rockets.map((rocket) => (
          <motion.div
            key={rocket.id}
            initial={{ 
              x: "-50%", 
              y: "115vh", 
              opacity: 0, 
              scale: rocket.scale * 0.4,
              rotate: 0 
            }}
            animate={{ 
              y: ["115vh", "82vh", "82vh", "-30vh"], 
              opacity: [0, 1, 1, 1, 0],
              scale: [rocket.scale * 0.4, rocket.scale * 0.85, rocket.scale * 0.85, rocket.scale * 1.1, rocket.scale * 0.5],
              rotate: [0, 0, 0, -4, 4, 0]
            }}
            exit={{ opacity: 0 }}
            transition={{ 
              duration: 3.2, 
              times: [0, 0.15, 0.31, 1], // Stays in launch position (82vh) for exactly 0.5s (from 15% to 31% of progress) to build suspense
              ease: ["easeOut", "linear", "anticipate"], // Anticipate makes the blast off look ultra premium & cinematic
            }}
            onAnimationComplete={() => removeRocket(rocket.id)}
            className="absolute z-[100000] flex flex-col items-center"
            style={{ left: `${rocket.left}%` }}
          >
            {/* Super realistic roaring flame exhaust */}
            {/* Main Outer Heatwave Shimmer Glow */}
            <div className="absolute top-[35px] w-12 h-12 rounded-full bg-orange-600/30 blur-lg animate-ping" />

            {/* Glowing Flame Body 1 (Wide High-Energy Orange Plasma Stream) */}
            <div className="absolute top-[32px] w-6 h-36 bg-gradient-to-b from-orange-500 via-amber-500 to-transparent rounded-full blur-[2px] animate-pulse origin-top" />
            
            {/* Glowing Flame Body 2 (Secondary Deep Red Plasma Stream) */}
            <div className="absolute top-[34px] w-8 h-24 bg-gradient-to-b from-rose-600 via-orange-500 to-transparent rounded-full blur-[4px] opacity-80 origin-top" />

            {/* Glowing Flame Body 3 (White-Hot Thermonuclear Fusion Core) */}
            <div className="absolute top-[31px] w-3 h-16 bg-gradient-to-b from-white via-yellow-200 to-transparent rounded-full blur-[0.5px] origin-top scale-y-110" />

            {/* Simulated flying embers/crackling sparks leaving a fire trail */}
            <div className="absolute top-[45px] w-2.5 h-2.5 bg-yellow-400 rounded-full animate-bounce blur-[0.5px] opacity-95" />
            <div className="absolute top-[60px] w-2 h-2 bg-rose-500 rounded-full animate-pulse blur-[0.5px] opacity-80" />
            <div className="absolute top-[80px] w-3.5 h-3.5 bg-amber-500 rounded-full blur-[1.5px] opacity-40 animate-ping" />
            
            {/* Expansive exhaust cloud/smoke puffs trailing behind the hot motor */}
            <div className="absolute top-[55px] w-8 h-8 bg-white/10 rounded-full blur-[6px] animate-pulse" />
            <div className="absolute top-[75px] w-6 h-6 bg-white/5 rounded-full blur-[8px]" />

            {/* Visual Icon Rocket (Slightly smaller, 5xl instead of 6xl, tilted to direction) */}
            <span 
              className="text-5xl select-none filter drop-shadow-[0_0_20px_rgba(239,68,68,0.7)] drop-shadow-[0_0_6px_rgba(251,191,36,0.5)] transform -rotate-45 block leading-none"
              style={{ display: "inline-block" }}
            >
              🚀
            </span>
          </motion.div>
        ))}
      </AnimatePresence>
    </div>
  );
}
