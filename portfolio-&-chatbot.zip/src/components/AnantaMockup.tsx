import React, { useState, useRef, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { 
  MessageSquare, 
  BookOpen, 
  Lightbulb, 
  CheckSquare, 
  ShieldCheck, 
  Heart, 
  Send,
  Sparkles,
  Bot,
  User,
  ArrowRight
} from "lucide-react";

interface Message {
  id: string;
  sender: "user" | "ananta";
  text: string;
  timestamp: string;
}

interface Feature {
  title: string;
  desc: string;
  suggestedPrompt: string;
  icon: React.ReactNode;
  color: string;
  shadow: string;
}

export default function AnantaMockup() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "initial",
      sender: "ananta",
      text: "Hello, I'm Ananta - Rutvik's digital companion. I'm here to assist with infinite possibilities and complete privacy. How can I help you today?",
      timestamp: "12:00 PM"
    }
  ]);
  const [inputVal, setInputVal] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const [activeFeature, setActiveFeature] = useState<string | null>(null);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isTyping]);

  const features: Feature[] = [
    {
      title: "Smart Conversations",
      desc: "I listen, I understand, I'm here for you.",
      suggestedPrompt: "Tell me about your natural language chat capabilities.",
      icon: <MessageSquare size={16} className="text-cyan-400" />,
      color: "border-cyan-500/25 bg-cyan-950/10 hover:border-cyan-400",
      shadow: "shadow-[0_0_15px_rgba(34,211,238,0.1)]"
    },
    {
      title: "Knowledge & Learning",
      desc: "I learn and grow so I can help you better.",
      suggestedPrompt: "How does your RAG-based search memory work?",
      icon: <BookOpen size={16} className="text-blue-400" />,
      color: "border-blue-500/25 bg-blue-950/10 hover:border-blue-400",
      shadow: "shadow-[0_0_15px_rgba(59,130,246,0.1)]"
    },
    {
      title: "Ideas & Inspiration",
      desc: "I spark ideas and help you see possibilities.",
      suggestedPrompt: "Can we brainstorm a collaborative marketing campaign idea for Rutvik?",
      icon: <Lightbulb size={16} className="text-amber-400" />,
      color: "border-amber-500/25 bg-amber-950/10 hover:border-amber-400",
      shadow: "shadow-[0_0_15px_rgba(245,158,11,0.1)]"
    },
    {
      title: "Task Assistant",
      desc: "I help you plan, organize and get things done.",
      suggestedPrompt: "How can you help manage my project milestones?",
      icon: <CheckSquare size={16} className="text-emerald-400" />,
      color: "border-emerald-500/25 bg-emerald-950/10 hover:border-emerald-400",
      shadow: "shadow-[0_0_15px_rgba(16,185,129,0.1)]"
    },
    {
      title: "Privacy First",
      desc: "Your data, your trust. Always protected.",
      suggestedPrompt: "Tell me about your strict on-device data isolation policy.",
      icon: <ShieldCheck size={16} className="text-pink-400" />,
      color: "border-pink-500/25 bg-pink-950/10 hover:border-pink-400",
      shadow: "shadow-[0_0_15px_rgba(244,114,182,0.1)]"
    },
    {
      title: "Emotional Support",
      desc: "I'm here to support you, anytime you need.",
      suggestedPrompt: "I've been feeling overwhelmed by finals. Do you have any guidance?",
      icon: <Heart size={16} className="text-rose-400" />,
      color: "border-rose-500/25 bg-rose-950/10 hover:border-rose-400",
      shadow: "shadow-[0_0_15px_rgba(244,63,94,0.1)]"
    }
  ];

  const handleSend = (textToSend: string) => {
    if (!textToSend.trim()) return;

    const userMsg: Message = {
      id: Date.now().toString(),
      sender: "user",
      text: textToSend,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setMessages(prev => [...prev, userMsg]);
    setInputVal("");
    setIsTyping(true);

    // Simulate smart context replies based on keyword matching
    setTimeout(() => {
      let replyText = "I'm processing that prompt through my active consciousness. My neural frameworks are set to deliver empathetic, intelligent support. Is there anything specific you would like to design today?";
      const lower = textToSend.toLowerCase();

      if (lower.includes("rag") || lower.includes("knowledge") || lower.includes("learning")) {
        replyText = "My learning core implements a modular Retrieval-Augmented Generation (RAG) system. I store continuous memory graphs of past interactions, matching semantic queries to long-term database nodes to maintain persistent, session-spanning relationships with complete privacy.";
      } else if (lower.includes("brainstorm") || lower.includes("idea") || lower.includes("marketing") || lower.includes("rutvik")) {
        replyText = "For Rutvik, we can combine his Marketing background with his AI expertise: For example, an 'AI-driven dynamic landing page builder' that uses sentiment analysis of incoming visitor queries to update layout structures instantly! Let's build that together.";
      } else if (lower.includes("task") || lower.includes("milestone") || lower.includes("plan")) {
        replyText = "My task orchestration layout maps nested goals with recursive breakdowns. By analyzing task priority vectors, I outline linear milestones and guide execution loops while preserving focus density.";
      } else if (lower.includes("privacy") || lower.includes("data") || lower.includes("isolated")) {
        replyText = "Privacy is core to ANANTA. All personal data graphs are fully isolated and client-side sandboxed. I never expose private training weights to external corporate entities, guaranteeing a secure, dedicated workspace.";
      } else if (lower.includes("overwhelmed") || lower.includes("support") || lower.includes("empathy")) {
        replyText = "Please take a deep breath. Together we can divide giant challenges into tiny, bite-sized tasks. I'm dynamically tuned to modulate my response latencies to keep things serene and clear. You are capable of great things!";
      } else if (lower.includes("chat") || lower.includes("conversation") || lower.includes("who are you")) {
        replyText = "I am ANANTA, Rutvik's custom-built digital twin of a warm, empathic AI. I balance ElevenLabs voice parameters, contextual memory banks, and high-fidelity interactive particles to serve as a supportive companion.";
      }

      const anantaMsg: Message = {
        id: (Date.now() + 1).toString(),
        sender: "ananta",
        text: replyText,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };

      setMessages(prev => [...prev, anantaMsg]);
      setIsTyping(false);
    }, 1500);
  };

  const selectFeature = (feature: Feature) => {
    setActiveFeature(feature.title);
    setInputVal(feature.suggestedPrompt);
  };

  return (
    <div className="w-full bg-[#030712] rounded-[2.5rem] border border-cyan-500/20 shadow-2xl shadow-cyan-950/20 p-6 md:p-8 relative overflow-hidden text-right flex flex-col min-h-[600px] text-left">
      {/* Background Starry Dust & Subtle Neon Gradients */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-cyan-700/10 rounded-full blur-[120px] animate-pulse"></div>
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-purple-700/10 rounded-full blur-[120px] animate-pulse"></div>
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,rgba(255,255,255,0.015)_1px,transparent_1px)] bg-[size:16px_16px]"></div>
      </div>

      <div className="relative z-10 flex flex-col flex-grow">
        {/* Header Branding */}
        <div className="text-center mb-8">
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="inline-flex items-center gap-1.5 px-3 py-1 bg-cyan-950/40 border border-cyan-400/20 rounded-full text-[10px] tracking-widest text-cyan-300 uppercase font-mono mb-3 shadow-[0_0_15px_rgba(34,211,238,0.15)]"
          >
            <Sparkles size={11} className="text-cyan-400 animate-spin-slow" /> ACTIVE DEMO PLATFORM
          </motion.div>
          <h2 className="text-3xl md:text-4xl font-extralight tracking-[0.35em] text-cyan-100 font-sans mt-1">
            ANANTA
          </h2>
          <p className="text-xs text-cyan-400/65 uppercase tracking-[0.25em] font-medium mt-1">
            Your Infinite AI Companion
          </p>
        </div>

        {/* Central Pulsating Orb System */}
        <div className="flex flex-col items-center justify-center py-6 min-h-[220px]">
          <div className="relative flex items-center justify-center">
            {/* Holographic Platform Base Rings */}
            <div className="absolute w-72 h-72 rounded-full border border-cyan-500/10 scale-y-[0.18] translate-y-28 opacity-40 blur-[1px]"></div>
            <div className="absolute w-56 h-56 rounded-full border-2 border-dashed border-cyan-400/20 scale-y-[0.18] translate-y-28 opacity-60 animate-spin-slow blur-[1px]"></div>
            <div className="absolute w-44 h-44 rounded-full bg-gradient-to-t from-cyan-500/20 to-transparent scale-y-[0.18] translate-y-28 blur-[6px] opacity-75"></div>

            {/* Glowing energy portal ring */}
            <motion.div
              animate={{ 
                scale: [1, 1.05, 1],
                boxShadow: [
                  "0 0 40px rgba(34,211,238,0.25)",
                  "0 0 60px rgba(168,85,247,0.35)",
                  "0 0 40px rgba(34,211,238,0.25)"
                ]
              }}
              transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
              className="w-36 h-36 rounded-full bg-gradient-to-tr from-cyan-900/45 via-slate-900/90 to-purple-950/45 border border-cyan-400/30 flex items-center justify-center z-10 backdrop-blur-xl relative"
            >
              {/* Inner glowing core web particles */}
              <div className="absolute inset-2 rounded-full bg-cyan-950/30 border border-purple-500/30 blur-[2px] animate-pulse"></div>
              
              {/* Central Glowing infinity symbol */}
              <motion.div 
                animate={{ scale: [0.95, 1.05, 0.95], opacity: [0.85, 1, 0.85] }}
                transition={{ duration: 2.5, repeat: Infinity, ease: "easeInOut" }}
                className="text-4xl md:text-5xl font-light text-cyan-300 drop-shadow-[0_0_12px_rgba(34,211,238,0.85)] z-20 cursor-pointer select-none"
                onClick={() => handleSend("Tell me about ananta") }
              >
                ∞
              </motion.div>
            </motion.div>

            {/* Orbiting particles */}
            <div className="absolute w-48 h-48 border border-white/5 rounded-full scale-[1.1] opacity-20 animate-pulse"></div>
          </div>
          <p className="text-[11px] text-cyan-300/50 font-mono tracking-widest uppercase mt-3 animate-pulse">
            Neural Synchronicity Core Live
          </p>
        </div>

        {/* Features Interactive Selection Hub Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3.5 mb-8">
          {features.map((feat) => (
            <button
              key={feat.title}
              onClick={() => selectFeature(feat)}
              className={`rounded-2xl border p-4 text-left transition-all duration-300 hover:-translate-y-0.5 relative group ${feat.color} ${feat.shadow} ${activeFeature === feat.title ? 'ring-1 ring-cyan-400 border-cyan-400 bg-cyan-950/20' : ''}`}
            >
              <div className="flex items-center gap-2.5 mb-1.5">
                <div className="p-1 px-1.5 rounded-lg bg-white/5 border border-white/10">
                  {feat.icon}
                </div>
                <h4 className="text-xs font-bold text-white tracking-wide group-hover:text-cyan-200">
                  {feat.title}
                </h4>
              </div>
              <p className="text-[11px] text-cyan-200/50 font-normal leading-relaxed">
                {feat.desc}
              </p>
              <div className="absolute bottom-2.5 right-2 px-1 text-[8px] bg-white/5 text-cyan-400 group-hover:bg-cyan-500 group-hover:text-black font-semibold rounded transform scale-0 group-hover:scale-100 transition-transform origin-right">
                TRY ME
              </div>
            </button>
          ))}
        </div>

        {/* Dynamic Chat & Interaction Shell Container */}
        <div className="bg-[#0b0f19] border border-cyan-500/15 rounded-3xl p-5 flex flex-col flex-grow min-h-[280px]">
          {/* Scrollable messages core */}
          <div 
            ref={scrollRef}
            className="flex-1 overflow-y-auto max-h-[180px] space-y-3.5 pb-2 scrollbar-thin scrollbar-thumb-cyan-950/50 pr-2"
            data-lenis-prevent
          >
            <AnimatePresence>
              {messages.map((msg) => (
                <motion.div
                  key={msg.id}
                  initial={{ opacity: 0, y: 5 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.3 }}
                  className={`flex gap-2.5 items-start max-w-[85%] ${msg.sender === "user" ? "ml-auto flex-row-reverse" : "mr-auto"}`}
                >
                  <div className={`w-6 h-6 rounded-lg flex items-center justify-center shrink-0 text-xs border ${msg.sender === "user" ? "bg-cyan-900/50 border-cyan-400/30 text-cyan-200" : "bg-purple-950/50 border-purple-400/30 text-purple-200"}`}>
                    {msg.sender === "user" ? <User size={12} /> : <Bot size={12} />}
                  </div>
                  <div>
                    <div className={`rounded-2xl px-3.5 py-2.5 text-xs font-normal leading-relaxed ${msg.sender === "user" ? "bg-cyan-950/70 border border-cyan-500/20 text-cyan-100" : "bg-[#111827] border border-white/5 text-slate-300"}`}>
                      {msg.text}
                    </div>
                    <span className="text-[9px] text-white/30 block mt-1 px-1 font-mono">
                      {msg.timestamp}
                    </span>
                  </div>
                </motion.div>
              ))}

              {isTyping && (
                <motion.div 
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="flex gap-2.5 items-start mr-auto"
                >
                  <div className="w-6 h-6 rounded-lg flex items-center justify-center shrink-0 text-xs border bg-purple-950/50 border-purple-400/30 text-purple-200 animate-pulse">
                    <Bot size={12} />
                  </div>
                  <div className="bg-[#111827] border border-white/5 text-slate-400 rounded-2xl px-3.5 py-2.5 text-xs flex gap-1 items-center">
                    <span className="w-1.5 h-1.5 bg-cyan-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }}></span>
                    <span className="w-1.5 h-1.5 bg-cyan-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }}></span>
                    <span className="w-1.5 h-1.5 bg-cyan-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }}></span>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {/* Form chat inputs */}
          <form 
            onSubmit={(e) => {
              e.preventDefault();
              handleSend(inputVal);
            }}
            className="mt-4 border-t border-cyan-500/10 pt-4 flex gap-2.5 relative items-center"
          >
            <input
              type="text"
              value={inputVal}
              onChange={(e) => setInputVal(e.target.value)}
              placeholder="Ask anything or click a prompt bubble above..."
              className="flex-1 bg-slate-950 border border-cyan-500/20 hover:border-cyan-500/40 focus:border-cyan-400 rounded-2xl px-4 py-3 text-xs text-white placeholder-cyan-400/30 outline-none transition-colors"
            />
            <button
              type="submit"
              disabled={!inputVal.trim() || isTyping}
              className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-cyan-500 to-indigo-500 disabled:from-slate-900 disabled:to-slate-900 hover:scale-105 disabled:hover:scale-100 flex items-center justify-center transition-all shadow-md shadow-cyan-900/10 border border-cyan-400/10 group active:scale-95 text-white"
            >
              <Send size={13} className="group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
            </button>
          </form>
        </div>

        {/* Bottom footer text */}
        <div className="text-center mt-6 z-10 select-none">
          <p className="text-[10px] text-cyan-400/35 font-mono tracking-[0.2em] uppercase">
            ∞ INFINITE POSSIBILITIES. INFINITE SUPPORT.
          </p>
        </div>
      </div>
    </div>
  );
}
